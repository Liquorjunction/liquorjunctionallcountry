<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Foundation\Auth\ThrottlesLogins;
use Illuminate\Session\Store;
use Illuminate\Validation\Rule;
use Auth;
use Illuminate\Config;
use Illuminate\Support\Facades\Hash;
use App\Models\Setting;
use App\Models\EmailTemplate;
use App\Models\Cart;
use App\Models\Order;
use App\Models\OrderDetails;
use App\Models\OrderInfo;
use App\Models\OrderTracking;
use App\Models\Product;
use App\Models\ProductVariants;
use App\Models\Promocode;
use App\Models\Transactions;
use App\Models\UsersPayments;
use App\Models\UserAddress;
use App\Models\Notification;
use App\Models\AdminNotifications;

use Mail;
use Carbon\Carbon;
use Cookie;
use Storage;
use DB;
use Session;
use File;
use Helper;
use Redirect;
use App\Models\Area;
use App\Models\Country;
use App\Models\Region;
use RealRashid\SweetAlert\Facades\Alert;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class CheckoutController extends Controller
{
    //
    public function __construct()
    {
        $this->setting = Setting::find(1);
        $this->user_id = isset(auth()
            ->guard('user')
            ->user()
            ->id) ? auth()
            ->guard('user')
            ->user()->id : '';
    }

    public function Checkout(Request $request)
    {
       
        // dd($request->all());

        // echo "<pre>";

        // print_r($request->all());
        // die;

    
        $user_id = $this->user_id;
        if ($this->user_id == '') {
            Session::put('checkout_value', 1);
        
            Session::put('pack_size', $request->pack_size);
            Session::put('counter', $request->counter);
            return redirect('login');
        }
        if(Session::get('checkout_value') == 1)
        {
            $variantIds = $request->pack_size ? $request->pack_size : Session::get('pack_size');
            $variant_quantity = $request->counter ? $request->counter : Session::get('counter');

            // $variantIds = Session::get('pack_size');
            // $variant_quantity = Session::get('counter');

        }
        else
        {
            
            $variantIds = $request->pack_size;
            $variant_quantity = $request->counter;
        }
           // Clear the session variables to reset the session for the cart
    Session::forget('checkout_value');
    Session::forget('pack_size');
    Session::forget('counter');

        $setting = $this->setting;
        //for buyNow
   
        $is_buy_now = 0;
        if ($request->pack_size == ""  && $variant_quantity == "") {
            $cartData = Cart::select(DB::raw('group_concat(product_variant_id) as variantIds'))->where('user_id', $user_id)->groupBy('user_id')->where('status', 1)->first();

            if (empty($cartData->variantIds)) {
                return Redirect::to('cart');
            }
            $variantIds = explode(',', $cartData->variantIds);

            $data = Cart::where('user_id', $user_id)->groupBy('user_id')->where('status', 1)->first();
            $productData = ProductVariants::whereIn('id', $variantIds)->get();
            foreach ($productData as $result) {

                $cart_data = Cart::where('product_variant_id', $result->id)->where('user_id', $user_id)->where('status', 1)->first();

                $offer_price = $result->variant_discounted_price;
                $varint_pro_price = $result->variant_price;
                if ($result->variant_discounted_price != '' && $result->variant_discounted_price != 0.00) {
                    $tcart_price = @$result->variant_discounted_price ? ($result->variant_discounted_price * $cart_data->quantity) : 0;
                } else {
                    $tcart_price = @$result->variant_price ? ($result->variant_price * $cart_data->quantity) : 0;
                }

                $cart_data->product_price = $varint_pro_price;
                $cart_data->offer_price = $offer_price;
                $cart_data->total_price = $tcart_price;
                $cart_data->save();
            }
        } else {
            //This is for buy now
            $variantIds = array($variantIds);
            $is_buy_now = 1;
        }

        $userData = \DB::table('main_users')->where('id', $user_id)->where('status', 1)->first();
        $countryData = \DB::table('countries')->orderby('phonecode', 'ASC')->get();
        $region = Region::where('status', 1)->orderby('title', 'ASC')->get();
        $area = Area::where('status', 1)->orderby('title', 'ASC')->get();
        $UserAddressData = UserAddress::withWhereHas('country', function ($query) {
            $query->where('status', 1);
        })->withWhereHas('region', function ($query) {
            $query->where('status', 1);
        })->withWhereHas('area', function ($query) {
            $query->where('status', 1);
        })->where([['user_id', $user_id], ['status', 1]])->get();
        // echo"<pre>";
        //  print_r(  $UserAddressData);
        //  die;
        //No need remove from here                           
        $store_address = DB::table('store_details')->where('id', $user_id)->where('status', 1)->get();

        $productData = ProductVariants::getProductDetalsBasedOnVariant()->with('cart')->whereIn('id', $variantIds)->get();

        if (count($productData) == 0) {
            //  Alert::success('Error', __('backend.something_went_wrong'));
            return redirect()->back();
        }
        //dd($productData);
        $current_lat = Session::get('current_lat');
        $current_long = Session::get('current_long');
        $setting = Setting::find(1);
        $diff = $setting->map_distance;
        if ($current_lat) {
            $storeMapData = DB::table('store_details')->select('store_details.*', DB::raw("(6371 * acos(cos(radians('" . $current_lat . "')) * cos(radians(store_details.latitude)) * cos( radians(store_details.longitude) - radians('" . $current_long . "')) + sin(radians('" . $current_lat . "')) * sin(radians(store_details.latitude)))) as distance"))->where('store_details.status', 1)
                ->havingRaw('distance <=' . $diff)->orderBy('distance', 'ASC')
                ->get();
        } else {
            // $storeMapData = DB::table('store_details1')
            //                 ->leftjoin('store_timing_week', 'store_timing_week.store_id', '=', 'store_details.id')
            //                 ->select('store_details.*')
            //                 ->orderby('store_details.id', 'DESC')
            //                 ->where('store_details.status', 1)
            //                 ->get();
            $storeMapData = DB::table('store_details')->orderby('store_details.id', 'DESC')->where('store_details.status', 1)->get();
            // dd($storeMapData);
        }

        // dd($storeMapData);
        $locations = [];
        foreach ($storeMapData as $key => $test) {
            $locations[] = array(
                "lat" => $test->latitude,
                "lng" => $test->longitude,
                "id" => $test->id
            );
        }
        if (empty($current_lat)) {
            $current_lat = $storeMapData[0]->latitude;
        }

        if (empty($current_long)) {
            $current_long = $storeMapData[0]->longitude;
        }
        return view("frontend.checkout.checkout", compact('userData', 'countryData', 'area', 'region', 'UserAddressData', 'store_address', 'storeMapData', 'locations', 'current_lat', 'current_long', 'productData', 'user_id', 'variant_quantity', 'is_buy_now'));
    }

    public function add_address(Request $request)
    {
        // $settings = Setting::find(1);
        // $key = $request->count;
        // $uofs = Uofs::where('status', 1)->orderBy('id', 'asc')->get();
        // $html = view('dashboard.product.addMoreVariant')->with(['key' => $key, 'settings' => $settings, 'uofs' => $uofs])->render();
        return response()->json(['success' => true, 'html' => $html]);
    }
    public function getSubcatlist(Request $request)
    {
        $id = $request->id;
        $data['sub'] = Region::where('country_id', '=', $id)->where('status', 1)
            ->get(["title", "id"]);
        return response()
            ->json($data);
    }
    public function getArealist(Request $request)
    {
        $id = $request->id;
        $data['sub'] = Area::where('region_id', '=', $id)->where('status', 1)
            ->get(["title", "id"]);
        return response()
            ->json($data);
    }

    public function checkouteditAddress($id)
    {
        $user_id = $this->user_id;
        $countryData = \DB::table('countries')
            ->orderby('phonecode', 'ASC')
            ->get();
        $region = Region::where('status', 1)->orderby('title', 'ASC')
            ->get();
        $area = Area::where('status', 1)->orderby('title', 'ASC')
            ->get();
        $UserAddressData = DB::table('user_address')->where('user_id', $user_id)->where('id', $id)->where('status', 1)
            ->first();
        $html = view('frontend.checkout.edit-address')->with(['UserAddressData' => $UserAddressData, 'countryData' => $countryData, 'region' => $region, 'area' => $area])->render();

        return response()
            ->json(['success' => true, 'html' => $html]);
    }

    public function geneateOrderId()
    {
        $uid = Order::orderBy('created_at', 'DESC')->first();
        if ($uid && $uid->id != null) {
            $temp_uid = (int)str_replace('LQ', '', $uid->id) + 1;
            $temp_uid = str_pad($temp_uid, 6, "0", STR_PAD_LEFT);
        } else {
            $temp_uid = 1;
            $temp_uid = str_pad($temp_uid, 6, "0", STR_PAD_LEFT);
        }
        return 'LQOID' . $temp_uid;
    }

    public function geneateTranscationId()
    {
        $uid = Transactions::orderBy('created_at', 'DESC')->first();
        if ($uid && $uid->id != null) {
            $temp_uid = (int)str_replace('LQTC', '', $uid->id) + 1;
            $temp_uid = str_pad($temp_uid, 6, "0", STR_PAD_LEFT);
        } else {
            $temp_uid = 1;
            $temp_uid = str_pad($temp_uid, 6, "0", STR_PAD_LEFT);
        }
        return 'LQTC' . $temp_uid;
    }

    // public function storePlaceOrder(Request $request)
    // {
    //     $user_id = $this->user_id;
    //     $user_address_id = $request->user_address_id;
    //     $payment_method = $request->payment_method;
    //     $purchase_type = $request->purchase_type;
    //     $delivery_charge = $request->delivery_charge;

    //     $store_location_id = $request->store_location_id;
    //     $coupon_code_id = $request->coupon_code_id;
    //     $coupon_percentage = $request->coupon_percentage;
    //     $tax = $request->tax;


    //     //If User apply poromo code
    //     if(!empty($coupon_code_id)){
    //         $promocode_data = Promocode::where('status',1)->where('id',$coupon_code_id)->first();
    //         if(!empty($promocode_data)){
    //             if($promocode_data->discount_percentage!=$coupon_percentage){
    //                 return response()->json(['error' => true,'message'=>@Helper::language('something_went_wrong'),'type'=>'coupon']);
    //             }
    //         }else{
    //             return response()->json(['error' => true,'message'=>@Helper::language('something_went_wrong'),'type'=>'coupon']);
    //         }
    //     }  

    //     $delivery_address = '';
    //     if(!empty($user_address_id) && $purchase_type==1){        
    //         $user_address_data = UserAddress::with(['country', 'region', 'area'])->where([['user_id', $user_id], ['status', 1],['id',$user_address_id]])->first();
    //         $status = $user_address_data->area->status;
    //         if($status==1){
    //             if($user_address_data->area->rate!=$delivery_charge){
    //                 return response()->json(['error' => true,'message'=>'Something went wrong in delivery fee.','type'=>'address']);
    //             }
    //         }else{
    //             return response()->json(['error' => true,'message'=>'Something went wrong in the delivery address.','type'=>'address']);
    //         }

    //         ($user_address_data->name)? $delivery_address = $user_address_data->name : '';
    //         ($user_address_data->address)? $delivery_address = $user_address_data->address : '';
    //         ($user_address_data->country->name)? $delivery_address .= ' ,| '.$user_address_data->country->name : '';
    //         ($user_address_data->region->title)? $delivery_address .= ' ,| '.$user_address_data->region->title : '';
    //         ($user_address_data->area->title)? $delivery_address .= ' ,| '.$user_address_data->area->title : '';
    //         ($user_address_data->phone)? $delivery_address .= ' ,| +'.$user_address_data->phone_code.' '.$user_address_data->phone : '';
    //     }

    //     //tax
    //     if($tax!=Helper::Settings('tax')){
    //         return response()->json(['error' => true,'message'=>@Helper::language('something_went_wrong'),'type'=>'tax']);
    //     }

    //     $store_id = '';
    //     $store_address='';
    //     if($store_location_id!=""){
    //         $store_data = DB::table('store_details')->where('id', $store_location_id)->where('status', 1)->first();
    //         $store_id = $store_data->id;
    //         $store_address = $store_data->store_name.', '.$store_data->address;
    //     }

    //     //For buy-now
    //     $is_buy_now =$request->is_buy_now;    
    //     if($is_buy_now==1){
    //         $variantIds = array($request->pvariant_Ids);
    //     }else{
    //         $cartData = Cart::select(DB::raw('group_concat(product_variant_id) as variantIds'))->where('user_id', $user_id)->groupBy('user_id')->where('status', 1)->first();
    //         if(empty($cartData)){
    //             return response()->json(['error' => true,'message'=>@Helper::language('something_went_wrong'),'type'=>'cart']);
    //         }
    //         $variantIds = explode(',', $cartData->variantIds);
    //     }

    //     $productData = ProductVariants::getProductDetalsBasedOnVariant()->with('cart')->whereIn('id', $variantIds)->get();

    //    /// dd($productData);
    //     $pcount = count($productData);
    //     $vcount = count($variantIds);
    //     // dd($pcount,$vcount);
    //     if($vcount!=$pcount){
    //         return response()->json(['error' => true,'message'=>@Helper::language('something_went_wrong'),'type'=>'product']);
    //     }

    //     $is_product_active = array();   
    //     $check_stock = array();   

    //     foreach($productData as $variant){
    //         if($variant->get_product_details->status==1 && $variant->get_product_details->get_category->status==1 && $variant->get_product_details->get_subcategory->status==1 && $variant->get_product_details->get_brand_details->status==1 ){
    //             $is_product_active[] =  false;
    //         }

    //         if($is_buy_now==1){
    //             $cart_qty = $request->buy_quantity;               
    //         }else{
    //             $cart_qty =Helper::getUserCartQuantity($variant->id,$user_id);
    //         }

    //         if($variant->available_qty < $cart_qty ){
    //             $check_stock[] = true;
    //         }
    //     }
    //     if(in_array('true',$check_stock)){
    //         return response()->json(['error' => true,'message'=>@Helper::language('something_went_wrong'),'type'=>'stock']);
    //     }

    //     if(in_array('false',$is_product_active)){
    //         return response()->json(['error' => true,'message'=>@Helper::language('something_went_wrong'),'type'=>'product_s']);
    //     }

    //     $userData = \DB::table('main_users')->where('id', $user_id)->where('status', 1)->first();
    //     ///dd($userData);
    //     $order_uid = uniqid();
    //     $order = new Order();
    //     $order->uniqid = $order_uid;
    //     $order->user_id = $user_id;
    //     $order->supplier_id = $store_id;
    //     $order->order_id = $this->geneateOrderId();
    //     $order->delivery_address = $delivery_address;
    //     $order->order_type = $purchase_type;
    //     $order->order_date = date('Y-m-d H:i:s');
    //     $order->order_time = date('Y-m-d H:i:s');
    //     $order->order_status = 1; //Pending
    //     $order->status = 1;
    //     $order->save();

    //     $tracking_id = uniqid();
    //     $order_tracking = new OrderTracking();
    //     $order_tracking->order_id = $order->id;
    //     $order_tracking->uniqid = $tracking_id;
    //     $order_tracking->order_status = 1;
    //     $order_tracking->status = 1;
    //     $order_tracking->save();

    //     $order_info = new OrderInfo();
    //     $order_info->order_id = $order->id;
    //     if($purchase_type==1){
    //         $order_info->country_id = $user_address_data->country_id;
    //         $order_info->region_id = $user_address_data->region_id;
    //         $order_info->area_id = $user_address_data->area_id;
    //     }        
    //     $order_info->customer_name = $userData->first_name.' '.$userData->last_name;
    //     $order_info->customer_mobile = $userData->phone_code.' '. $userData->phone  ;
    //     $order_info->customer_email = $userData->email;
    //     $order_info->customer_country = ($userData->country_code)?:'' ;
    //     $order_info->order_from = '1';
    //     if($purchase_type==2){
    //         $order_info->store_pickup_address = $store_address;
    //     }
    //     $order_info->save();

    //     $original_price = 0;
    //     $total_discount_price = 0;
    //     $product_discount_price =0;
    //     $is_product_discount[] =  false;
    //     foreach ($productData as $result)
    //     {
    //         if($is_buy_now==1){
    //             $cart_qty = $request->buy_quantity;
    //         }else{
    //             $cart_qty =Helper::getUserCartQuantity($result->id,$user_id);
    //             //using for variant new price
    //             $cart_info = Cart::where(['product_variant_id'=>$result->id,'user_id'=>$user_id,'status'=>1])->first();

    //         }

    //         $product_unit = Helper::getUnitById($result->variant_uof);
    //         //$product_total_price = ($cart_qty * $result->variant_discounted_price);
    //         $order_detail = new OrderDetails();
    //         $order_detail->order_id = @$order->id;
    //         $order_detail->product_id = $result->get_product_details->id;
    //         $order_detail->customer_id = $user_id ;
    //         $order_detail->product_original_amount = $result->variant_price;
    //         $order_detail->product_total_amount = ($result->variant_discounted_price)?$result->variant_discounted_price:'';
    //         $order_detail->quantity = $cart_qty;  
    //         $order_detail->variant_size = $result->variant_size;   
    //         $order_detail->variant_unit = $result->variant_uof;         
    //         $order_detail->status = 1;
    //         $order_detail->save();            

    //         $org_price = @$result->variant_price ? ($result->variant_price * $cart_qty) : 0;
    //         $original_price += $org_price;      
    //         $product_discount_price = @$result->variant_discounted_price ? ($result->variant_discounted_price * $cart_qty) : 0;
    //         if($result->variant_discounted_price !='' && $result->variant_discounted_price != 0.00){ 
    //             $total_discount_price += ($org_price - $product_discount_price);
    //             $is_product_discount[] = true;
    //         }


    //         $available_qty = $result->available_qty - $cart_qty;
    //         $sold_qty = $result->sold_qty + $cart_qty;

    //         ProductVariants::where('id', $result->id)->update(array('available_qty'=>$available_qty,'sold_qty'=>$sold_qty));
    //     }

    //     $total_products_price = $original_price;
    //     if(in_array(true, $is_product_discount)){
    //         $product_sub_total_amount = ($total_products_price -  $total_discount_price);
    //         $grand_total_amount =  ($total_products_price -  $total_discount_price);
    //     }else{
    //         $product_sub_total_amount =$total_products_price;
    //         $grand_total_amount =  $total_products_price;
    //     }

    //     //Tax 
    //     if(Helper::Settings('tax')!=0 && $tax!=""){
    //         $tax  = ($tax / 100) * $grand_total_amount;            
    //         $tax_amount =  round($tax,2);
    //         Order::where('id', $order->id)->update(array('tax'=>$tax_amount));
    //         $grand_total_amount =round(($grand_total_amount + $tax_amount), 2);
    //     }


    //     $coupon_code_price = '';
    //     $promo_title = '';
    //     $couponPercentage ='';

    //     if(!empty($promocode_data)){
    //         $promo_title = $promocode_data->promo_name;
    //         $couponPercentage = $promocode_data->discount_percentage;
    //         $coupon_code_price = ($couponPercentage / 100) * $grand_total_amount;
    //         $sub_total_amount = ($grand_total_amount - round($coupon_code_price, 2));
    //         OrderInfo::where('order_id', $order->id)
    //                     ->update(array('promocode_name'=>$promo_title,
    //                                     'promocode_percentage'=>$couponPercentage));
    //         $grand_total_amount = $sub_total_amount;
    //     }



    //     if(!empty($user_address_id) && $purchase_type==1){
    //         $area_tax_rate = round($user_address_data->area->rate, 2);
    //         $grand_total_amount = round($grand_total_amount + $area_tax_rate,2);
    //         OrderInfo::where('order_id', $order->id)->update(array('delivery_fee'=>$area_tax_rate));
    //     } 


    //     $transactions = new Transactions();
    //     $transactions->trans_no = $this->geneateTranscationId();
    //     $transactions->user_id = $user_id;
    //     $transactions->order_id = @$order->id;
    //     $transactions->payment_type = $payment_method;
    //     $transactions->payment_status = '1';
    //     $transactions->amount = $grand_total_amount;
    //     $transactions->transaction_date = date('Y-m-d H:i:s');
    //     $transactions->status = 1;
    //     $transactions->save();


    //     $userData = DB::table('main_users')->where('id',$user_id)->first();
    //     $title = "Online Order Confirm";
    //     $message = "Online Order Confirm";
    //     $remember_token = "fYPZqDsO90pgmZAzTKD0ow:APA91bEF6Pv3waTLBb8lRSUCrjz_M3Vxf14zF3IDHBckRoI79Ojw66aRbuDNhuHWT21qsPYwhOvXxGhILv-nJ0ZCNWzEEuo2tWQ1pDULgeBkPPoAbPaV6ulPJ0W1H8zhA2IcPn8zHl8P";
    //     $device_token = $userData->device_token;
    //     // echo "<pre>";print_r($device_token);exit();
    //     $device_type = 1;

    //     $notification = new Notification();
    //     $notification->order_id = @$order->id;
    //     $notification->sender_id = @$user_id;
    //     $notification->receiver_id = @$user_id;
    //     $notification->notification_type = 1;
    //     $notification->title = @$title;
    //     $notification->message = @$message;
    //     $notification->is_read = 0;
    //     $notification->save();

    //     //  $response = (new \Helper)->send_notification_FCM($remember_token, $title, $message, $device_type);
    //     // $response = (new \Helper)->sendNotification($device_token, $title, $message, $device_type);
    //     //300+30 = 330
    //     $this->sendOrderConfirmationEmail($user_id, $order);
    //     $updatepsw = Order::where('user_id', $user_id)->where('id', $order->id)
    //     ->update(array('total_amount'=>$product_sub_total_amount,
    //     'payable_amount'=>$grand_total_amount,
    //     'discount_amount'=>$coupon_code_price)
    // );
    //     // $html = view('frontend.checkout.success-checkout')->with(['trans_no' => '', 'uniqid' =>'', 'store_name' => ''])->render();
    //    return response()->json(['success' => true,'order_id'=>Helper::encodeUrl($order->id)]);
    // }

    // public function sendOrderConfirmationEmail($user_id, $order)
    // {
    //     $customerDetails = DB::table('main_users')->find($user_id);
    //     $setting = Setting::find(1);
    //     $templateId = 17; // You should determine the appropriate template ID
    //     $emailDetail = EmailTemplate::find($templateId);
    //    // $fromEmail = $setting['mail_username'];
    //    $fromEmail = env('MAIL_USERNAME');
    //     $logo = asset('assets/dashboard/images/Logo/logo.png');
    //     $sendEmail = $customerDetails->email;
    //     // dd($customerDetails);
       
    //     $data = [
    //         'user_name' => $customerDetails->first_name,
    //         'sendname' => $customerDetails->first_name,
    //         'sendemail' => $sendEmail,
    //         'id' => $templateId,
    //         'order' => $order,
    //         'order_status' => "Place Order",
    //         'from_email' => $fromEmail,
    //     ];
    //      //dd($data);
    //     try {
    //         // Mail::send('emails.orderstatuschanged', $data, function ($message) use ($data, $emailDetail) {
    //         //     $message->to($data['sendemail'], 'Liquor')->subject($emailDetail->subject);
    //         //     $message->from($data['from_email'], $emailDetail->title);
    //         // });

    //         $student_email = $customerDetails->email;
    //         $subject = 'order plsce';
    //         $email = 'Static test function for rder LJ';
        
    //        $res_mail =  Mail::raw($email, function ($message) use ($student_email, $subject) {
    //             $message->to($student_email)->subject($subject);
    //         });


            
    //         $admin_email = "info@liquorjunctionghana.com";
    //         $subject = 'new order recived';
    //         $email = 'Testing user order notification';
        
    //        $res2_mail =  Mail::raw($email, function ($message) use ($admin_email, $subject) {
    //             $message->to($admin_email)->subject($subject);
    //         });


    //     } catch (\Throwable $th) {
    //         return response()->json(['success' => false, 'msg' => 'something went wrong.']);
    //     }
    // }

//     public function sendOrderConfirmationEmail($user_id, $order)
// {
//     $order_detail = OrderDetails::where('order_id', $order->id)->first();
//     // print_r($order_detail);
//     // die;
//     $transactions = Transactions::where('order_id', $order->id)->first();
//     $product = Product::where('id', $order_detail->product_id)->first();
//     //   print_r($product);
//     //   die;

//     // Fetch customer details
//     $customerDetails = DB::table('main_users')->find($user_id);
//     $setting = Setting::find(1);
//     $templateId = 17; // You should determine the appropriate template ID
//     $emailDetail = EmailTemplate::find($templateId);
//     $fromEmail = env('MAIL_FROM_ADDRESS', 'info@liquorjunctionghana.com'); 
//     $logo = asset('assets/dashboard/images/Logo/logo.png');
//     $sendEmail = $customerDetails->email;
//    //dd($emailDetail);
//     // Prepare email data
//     $data = [
//         'user_name' => $customerDetails->first_name,
//         'sendname' => $customerDetails->first_name,
//         'sendemail' => $customerDetails->email,
//         'id' => $templateId,
//         'order' => $order,
//         'order_status' => "Place Order",
//         'from_email' =>config('mail.from.address'),
//         //'total_amount' => $order->payable_amount,
//     ];

//     //echo "order_amout";

//     $order_amount = Order::with('transcations')->where('id', $order->id)->first();
// //     echo "<pre>";
// //     print_r($order_amout);
// //     die;
// // dd($data);
//     try {
//         // Send email to customer
//         Mail::send('emails.orderstatuschanged', $data, function ($message) use ($data,  $emailDetail) {
//             $message->to($data['sendemail'], 'Liquor')->subject( $emailDetail->subject);
//             $message->from($data['from_email'], $emailDetail->title);
//         });
//         //dd($message);

//        // Send email to admin
//         $adminEmail = 'info@liquorjunctionghana.com';
//         $adminSubject = 'New Order Received';
//         //$adminEmailContent = "A new order has been received. Order ID: " . $order->order_id; 
//         //$adminEmailContent = "A new order has been received.\n\nOrder Details:\nOrder ID: " . $order->order_id . "\n\nCustomer Details:\nName: " . $customerDetails->first_name . " " . $customerDetails->last_name . "\nEmail: " . $customerDetails->email . "\nPhone: " . $customerDetails->phone; // Customize as needed

//         // $adminEmailContent = "A new order has been received.\n\nCustomer Details:\n" .
//         //                      "Name: " . $customerDetails->first_name . " " . $customerDetails->last_name . "\n" .
//         //                      "Email: " . $customerDetails->email . "\n" .
//         //                      "Phone: " . $customerDetails->phone . "\n" .
//         //                      "Delivery Address: " . $order->delivery_address . "\n\n" .
//         //                      "Order Details:\n" .
//         //                      "Order ID: " . $order->order_id . "\n" .
//         //                      "Order Type: " . $order->order_type . "\n" .
//         //                      "Order Date: " . $order->order_date . "\n" .
//         //                      "Order Time: " . $order->order_time . "\n" .
//         //                      "Order Status: " . ($order->order_status == 1 ? 'Pending' : 'Other') . "\n" .
//         //                      "Payment Method Status: " . ($order->status == 2 ? 'Paid' : 'Pending') . "\n\n" .
//         //                      "Product Details:\n" .
//         //                      "Transaction Number: " .  $transactions->trans_no . "\n" .
//         //                      "Original Amount: " . $order_detail->product_original_amount . "\n" .
//         //                      "Total Amount: " . $order_detail->product_total_amount . "\n" .
//         //                      "Quantity: " . $order_detail->quantity . "\n" .
//         //                      "Variant Size: " .$order_detail->variant_size . "\n" .
//         //                      "Variant Unit: " . $order_detail->variant_unit;


//         // $order_type_name = ($order->order_type == 1) ? "Online Order" : "In-store";

//         if ($order->order_type == 1) {
//             $order_type_name = "Online Order";
//         } elseif ($order->order_type == 2) {
//             $order_type_name = "In-store";
//         } elseif ($order->order_type == 3) {
//             $order_type_name = "Purchase Order";
//         } else {
//             $order_type_name = "Unknown Order Type";
//         }

//         if ($transactions->payment_type == 1) {
//             $payment_type_name = "Momo Pay";
//         } elseif ($transactions->payment_type == 2) {
//             $payment_type_name = "Card (Debit/Credit)";
//         } elseif ($transactions->payment_type == 3) {
//             $payment_type_name = "Cash on Delivery";
//         } else {
//             $payment_type_name = "Unknown Payment Type";
//         }
        
//         $adminEmailContent = "
// <html>
// <head>
//     <style>
//         body { font-family: Arial, sans-serif; }
//         .container { width: 100%; padding: 20px; }
//         .content { background-color: #f9f9f9; padding: 15px; border-radius: 5px; }
//         .header { font-size: 18px; font-weight: bold; margin-bottom: 10px; }
//         .item { margin-bottom: 10px; display: flex; }
//         .label { font-weight: bold; width: 150px; }
//         .value { margin-left: 10px; flex: 1; }
//     </style>
// </head>
// <body>
//  <div class='container' style='background-color: #f1f1f1; width: 100%; padding: 20px; margin-top: -100px;'>
//         <div class='content'>
//             <div class='header' style='font-size: 18px; font-weight: bold; margin-bottom: 10px;'><b>A new order has been received.</b></div>
//             <div class='item'><span class='label'><b>Customer Details:</b></span></div>
//             <div class='item'><span class='label'>Name:</span>  <span class='value'>{$customerDetails->first_name} {$customerDetails->last_name}</span></div>
//             <div class='item'><span class='label'>Email:</span>  <span class='value'>{$customerDetails->email}</span></div>
//             <div class='item'><span class='label'>Phone:</span>  <span class='value'>{$customerDetails->phone}</span></div>
//             <div class='item'><span class='label'>Delivery Address:</span>  <span class='value'>{$order->delivery_address}</span></div>
//             <div class='item'><span class='label'><b>Order Details:</b></span></div>
//             <div class='item'><span class='label'>Order ID:</span>  <span class='value'>{$order->order_id}</span></div>
//             <div class='item'><span class='label'>Order Type:</span>  <span class='value'>{$order_type_name}</span></div>
//             <div class='item'><span class='label'>Order Date:</span>  <span class='value'>{$order->order_date}</span></div>
//             <div class='item'><span class='label'>Order Time:</span>  <span class='value'>{$order->order_time}</span></div>
//             <div class='item'><span class='label'>Order Status:</span>  <span class='value'>" . ($order->order_status == 1 ? 'Pending' : 'Other') . "</span></div>
//             <div class='item'><span class='label'>Payment Method:</span>  <span class='value'>{$payment_type_name} </span></div>
//             <div class='item'><span class='label'><b>Product Details:</b></span></div>
//             <div class='item'><span class='label'>Transaction Number:</span>  <span class='value'>{$transactions->trans_no}</span></div>
//             <div class='item'><span class='label'>Product Name:</span>  <span class='value'>{$product->product_name}</span></div>
//             <div class='item'><span class='label'>Original Amount:</span>  <span class='value'>{$order_detail->product_original_amount}</span></div>
//             <div class='item'><span class='label'>Total Amount:</span>  <span class='value'>{$order_amount->payable_amount}GH₵</span></div>
//             <div class='item'><span class='label'>Quantity:</span>  <span class='value'>{$order_detail->quantity}</span></div>
//             <div class='item'><span class='label'>Variant Size:</span>  <span class='value'>{$order_detail->variant_size}</span></div>
//             <div class='item'><span class='label'>Variant Unit:</span>  <span class='value'>{$order_detail->variant_unit}</span></div>
//         </div>
//     </div>
// </body>
// </html>";

//     //    print_r($adminEmailContent);
//     //    die;
//         Mail::raw($adminEmailContent, function ($message) use ($adminEmail, $adminSubject) {
//             $message->to($adminEmail)
//                 ->subject($adminSubject)
//                 ->from(env('MAIL_FROM_ADDRESS'), env('MAIL_FROM_NAME')); // Ensure this is properly configured in your .env file
//         });

//     } catch (\Throwable $th) {
//         // Log the error for debugging
//         \Log::error('Email sending failed: ' . $th->getMessage());
//         return response()->json(['success' => false, 'msg' => 'Something went wrong while sending email.']);
//     }

//     return response()->json(['success' => true, 'msg' => 'Emails sent successfully.']);
// }

public function sendOrderConfirmationEmail($user_id, $order)
{
    $order_details = OrderDetails::where('order_id', $order->id)->get(); // Get all order details
    $transactions = Transactions::where('order_id', $order->id)->first();
    $order_info = OrderInfo::where('order_id', $order->id)->first();
// print_r($order_info);
// die;
    // Fetch customer details
    $customerDetails = DB::table('main_users')->find($user_id);
    $setting = Setting::find(1);
    $templateId = 17; // Determine the appropriate template ID
    $emailDetail = EmailTemplate::find($templateId);
    $fromEmail = env('MAIL_FROM_ADDRESS', 'info@liquorjunctionghana.com'); 
    $sendEmail = $customerDetails->email;

    // Prepare email data
    $data = [
        'user_name' => $customerDetails->first_name,
        'sendname' => $customerDetails->first_name,
        'sendemail' => $customerDetails->email,
        'id' => $templateId,
        'order' => $order,
        'order_status' => "Place Order",
        'from_email' => config('mail.from.address'),
    ];

    $order_amount = Order::with('transcations')->where('id', $order->id)->first();

    try {
        // Send email to customer
        Mail::send('emails.orderstatuschanged', $data, function ($message) use ($data,  $emailDetail) {
            $message->to($data['sendemail'], 'Liquor')->subject($emailDetail->subject);
            $message->from($data['from_email'], $emailDetail->title);
        });

        // Send email to admin
        $adminEmail = 'info@liquorjunctionghana.com';
        $adminSubject = 'New Order Received';

        if ($order->order_type == 1) {
                        $order_type_name = "Online Order";
                    } elseif ($order->order_type == 2) {
                        $order_type_name = "In-store";
                    } elseif ($order->order_type == 3) {
                        $order_type_name = "Purchase Order";
                    } else {
                        $order_type_name = "Unknown Order Type";
                    }
            
                    if ($transactions->payment_type == 1) {
                        $payment_type_name = "Momo Pay";
                    } elseif ($transactions->payment_type == 2) {
                        $payment_type_name = "Card (Debit/Credit)";
                    } elseif ($transactions->payment_type == 3) {
                        $payment_type_name = "Cash on Delivery";
                    } else {
                        $payment_type_name = "Unknown Payment Type";
                    }

                    if ($order_info) {
                        if ($order_info->order_from == 1) {
                            $order_type_from = 'Web';
                        } elseif ($order_info->order_from == 2) {
                            $order_type_from = 'Android';
                        } elseif ($order_info->order_from == 3) {
                            $order_type_from = 'iOS';
                        } else {
                            $order_type_from = 'Unknown Source';
                        }
                    } else {
                        $order_type_from = 'Unknown Source';
                    }
        // Initialize the admin email content with the basic details
        $adminEmailContent = "
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; }
        .container { width: 100%; padding: 20px; }
        .content { background-color: #f9f9f9; padding: 15px; border-radius: 5px; }
        .header { font-size: 18px; font-weight: bold; margin-bottom: 90px; }
        .item { margin-bottom: 10px; display: flex; }
        .label { font-weight: bold; width: 150px; }
        .value { margin-left: 10px; flex: 1; }
        .table { width: 100%; border-collapse: collapse;}
        .table th, .table td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        .table th { background-color: #f2f2f2; }
        .total-row { font-weight: bold; }
        .amount-cell { text-align: right; }
        br { display: none; } 
    </style>
</head>
<body>
        <div class='container' style='background-color: #f1f1f1; width: 100%; padding: 20px; margin-top: -50px;'>
        <div class='content'>
            <div class='header'><b>A new order has been received.</b></div>
            <div class='item'><span class='label'><b>Customer Details:</b></span></div>
            <div class='item'><span class='label'>Name:</span>  <span class='value'>{$customerDetails->first_name} {$customerDetails->last_name}</span></div>
            <div class='item'><span class='label'>Email:</span>  <span class='value'>{$customerDetails->email}</span></div>
            <div class='item'><span class='label'>Phone:</span>  <span class='value'>+{$customerDetails->phone_code}{$customerDetails->phone}</span></div>
            <div class='item'><span class='label'>Delivery Address:</span>  <span class='value'>{$order->delivery_address}</span></div>
            <div class='item'><span class='label'><b>Order Details:</b></span></div>
            <div class='item'><span class='label'>Order ID:</span>  <span class='value'>{$order->order_id}</span></div>
            <div class='item'><span class='label'>Order Type:</span>  <span class='value'>{$order_type_name}</span></div>
             <div class='item'><span class='label'>Order From:</span>  <span class='value'>{$order_type_from}</span></div>
            <div class='item'><span class='label'>Order Date:</span>  <span class='value'>{$order->order_date}</span></div>
            <div class='item'><span class='label'>Order Time:</span>  <span class='value'>{$order->order_time}</span></div>
            <div class='item'><span class='label'>Delivery Status:</span>  <span class='value'>" . ($order->order_status == 1 ? 'Pending' : 'Other') . "</span></div>
            <div class='item'><span class='label'>Payment Method:</span>  <span class='value'>{$payment_type_name}</span></div>
           <div class='item' style='margin-bottom: 0;'>
                 <span class='label'><b>Product Details:</b></span>
           </div>
            <table class='table' style='margin-top: -170px;'>
                <tr>
                    <th style='padding: 5px;'>Product Name</th>
                    <th style='padding: 5px;'>Product Size</th>
                    <th style='padding: 5px;'>Qty</th>
                    <th style='padding: 5px;' class='amount-cell'>Amount</th>
                    <th style='padding: 5px;' class='amount-cell'>Total</th>
                </tr>";

        // Loop through each product in the order
        foreach ($order_details as $order_detail) {
            $product = Product::where('id', $order_detail->product_id)->first();
            $total_amount = $order_detail->quantity * $order_detail->product_original_amount;

            $adminEmailContent .= "
            <tr>
                <td style='padding: 10px;'>{$product->product_name}</td>
                <td style='padding: 10px;'>{$order_detail->variant_size}ML</td>
                <td style='padding: 15px;'>{$order_detail->quantity}</td>
                <td style='padding: 10px;' class='amount-cell'>{$order_detail->product_original_amount} GH₵</td>
                <td style='padding: 10px;' class='amount-cell'>{$total_amount} GH₵</td>
            </tr>";
        
        }

        // Add subtotal, discount, tax, delivery fee, and total amount
        $adminEmailContent .= "
        <tr class='total-row'>
            <td style='padding: 10px;' colspan='7'>Sub Amount</td>
            <td style='padding: 10px;' class='amount-cell'>{$order_amount->total_amount} GH₵</td>
        </tr>
        <tr class='total-row'>
            <td style='padding: 10px;' colspan='7'>Discount Amount</td>
            <td style='padding: 10px;' class='amount-cell'>- {$order_amount->discount_amount} GH₵ ({$order_info->promocode_name})</td>
        </tr>
        <tr class='total-row'>
            <td style='padding: 10px;' colspan='7'>Tax</td>
            <td style='padding: 10px;' class='amount-cell'>{$order_amount->tax} GH₵</td>
        </tr>
        <tr class='total-row'>
            <td style='padding: 10px;' colspan='7'>Delivery Fee</td>
            <td style='padding: 10px;' class='amount-cell'>{$order_info->delivery_fee} GH₵</td>
        </tr>
        <tr class='total-row'>
            <td style='padding: 10px;' colspan='7'>Total Amount</td>
            <td style='padding: 10px;' class='amount-cell'>{$order_amount->payable_amount} GH₵</td>
        </tr>
            </table>
        </div>
    </div>
</body>
</html>";
// print_r( $adminEmailContent);
// die;

        Mail::raw($adminEmailContent, function ($message) use ($adminEmail, $adminSubject) {
            $message->to($adminEmail)
                ->subject($adminSubject)
                ->from(env('MAIL_FROM_ADDRESS'), env('MAIL_FROM_NAME')); // Ensure this is properly configured in your .env file
        });

    } catch (\Throwable $th) {
        // Log the error for debugging
        \Log::error('Email sending failed: ' . $th->getMessage());
        return response()->json(['success' => false, 'msg' => 'Something went wrong while sending email.']);
    }

    return response()->json(['success' => true, 'msg' => 'Emails sent successfully.']);
}


    public function orderSuccess(Request $request, $id)
    {
        $orderData = Order::where('id', base64_decode($id))->first();
        return view('frontend.checkout.order-success', compact('orderData'));
    }

    public function orderSuccessCard(Request $request, $userid, $orderid, $amount)
    {
        // echo "string";exit;
        $orderId = $orderid;
        $userId = $userid;
        $Amount = $amount;

        $orderData = Order::find($orderid);
        $orderData->status = 1;
        if ($orderData->save()) {
            try {
                $tranId = @$_GET['TransID'] ?: $this->geneateTranscationId();
                $transactions = Transactions::where('order_id', $orderId)->update(['status' => 1]);

                $orderDetails = OrderDetails::where('order_id', $orderData->id)->get();

                if (!empty($orderDetails) && $orderData->is_stock_updated != 1) {
                    foreach ($orderDetails as $item) {
                        $existing = ProductVariants::find($item->variant_id);
                        $available_qty = $existing->available_qty - $item->quantity;
                        $sold_qty = $existing->sold_qty + $item->quantity;

                        $existing->available_qty = $available_qty;
                        $existing->sold_qty = $sold_qty;
                        $existing->save();
                    }
                    $updatStockStatus = Order::find($orderData->id);
                    $updatStockStatus->is_stock_updated = 1;
                    $updatStockStatus->save();

                    $userData = DB::table('main_users')->where('id', $userId)->first();
                    $title = "Online Order Confirm";
                    $message = "Online Order Confirm";
                    $remember_token = "fYPZqDsO90pgmZAzTKD0ow:APA91bEF6Pv3waTLBb8lRSUCrjz_M3Vxf14zF3IDHBckRoI79Ojw66aRbuDNhuHWT21qsPYwhOvXxGhILv-nJ0ZCNWzEEuo2tWQ1pDULgeBkPPoAbPaV6ulPJ0W1H8zhA2IcPn8zHl8P";
                    $device_token = $userData->device_token;
                    // echo "<pre>";print_r($device_token);exit();
                    $device_type = 1;

                    $notification = new Notification();
                    $notification->order_id = @$orderData->id;
                    $notification->sender_id = @$userId;
                    $notification->receiver_id = @$userId;
                    $notification->notification_type = 1;
                    $notification->title = @$title;
                    $notification->message = @$message;
                    $notification->is_read = 0;
                    $notification->save();

                    $this->sendOrderConfirmationEmail($userId, $orderData);
                }

                return view('frontend.checkout.order-success', compact('orderData'));
            } catch (\Throwable $th) {
                abort(404);
            }
        }
    }


    public function SelectedAddress(Request $request)
    {
        // echo "<pre>";print_r($request->toArray());exit();
        $user_id = $this->user_id;
        $address_id = $request->address_id;
        // dd($address_id);
        $updatepsw = UserAddress::where('user_id', $user_id)->update(array(
            'is_selected_address_id' => 0,
        ));

        $updateaddress = UserAddress::where('user_id', $user_id)->where('id', $address_id)->update(array(
            'is_selected_address_id' => 1,
        ));

        Alert::success(\Helper::language('success'), __('backend.address_change_successfully'));
        return response()
            ->json(['success' => 'true']);
    }

    public function storeSessionLat(Request $request)
    {
        // echo "<pre>";
        // print_r($request->lat);
        // exit();
        //  $current_lat = Session::set('current_lat', $request->lat);
        // $current_long = Session::set('current_long', $request->lng);
        \Session::put('current_lat', $request->lat);
        \Session::put('current_long', $request->lng);
        return response()
            ->json(['success' => true]);
    }

    public function getUserAreaTax(Request $request)
    {
        $user_id = $this->user_id;
        $user_address_id = $request->user_address_id;
        $coupon_code_id = $request->coupon_code_id;

        //For buy-now
        $is_buy_now = $request->is_buy_now;
        if ($is_buy_now == 1) {
            $variantIds = array($request->pvariant_Ids);
        } else {
            $cartData = Cart::select(DB::raw('group_concat(product_variant_id) as variantIds'))->where('user_id', $user_id)->groupBy('user_id')->where('status', 1)->first();
            $variantIds = explode(',', $cartData->variantIds);
        }

        $productData = ProductVariants::getProductDetalsBasedOnVariant()->with('cart')->whereIn('id', $variantIds)->get();

        $area_tax_rate = 0;
        $product_discounted_price = 0;
        $coupon_code_price = 0;
        $grand_total_amount = 0;
        $tax_amount = 0;
        $original_price = 0;
        $total_discount_price = 0;
        $is_product_discount[] =  false;
        foreach ($productData as $result) {
            if ($is_buy_now == 1) {
                $org_price = @$result->variant_price ? ($result->variant_price * $request->buy_quantity) : 0;
                $original_price += $org_price;
                $product_discounted_price = @$result->variant_discounted_price ? ($result->variant_discounted_price * $request->buy_quantity) : 0;
            } else {
                $org_price = @$result->variant_price ? ($result->variant_price *  Helper::getUserCartQuantity($result->id, $user_id)) : 0;
                $original_price += $org_price;
                $product_discounted_price += @$result->variant_discounted_price ? ($result->variant_discounted_price * Helper::getUserCartQuantity($result->id, $user_id)) : 0;
            }

            if ($result->variant_discounted_price != '' && $result->variant_discounted_price != 0.00) {
                $total_discount_price += ($org_price - $product_discounted_price);
                $is_product_discount[] = true;
            }
        }
        $total_products_price = @Helper::numberFormat($original_price);

        if (in_array(true, $is_product_discount)) {
            $grand_total_amount =  ($total_products_price -  $total_discount_price);
        } else {
            $grand_total_amount =  $total_products_price;
        }

        //Discount is apply only product price not with including delivery charege
        if (!empty($coupon_code_id)) {
            $promocode_data = Promocode::where('id', $coupon_code_id)->where('status', 1)->first();
            $coupon_code_price = ($promocode_data->discount_percentage / 100) * $grand_total_amount;
            $coupon_code_price = @Helper::numberFormat($coupon_code_price);
            $grand_total_amount = ($grand_total_amount - $coupon_code_price);
        }

        //Tax 
        if (Helper::Settings('tax') != 0) {
            $tax_amount =  @Helper::numberFormat((Helper::Settings('tax') / 100) * $grand_total_amount);
            $grand_total_amount = $grand_total_amount + $tax_amount;
        }

        if (!empty($user_address_id)) {
            $user_address_data = UserAddress::with(['country', 'region', 'area'])->where([['user_id', $user_id], ['status', 1], ['id', $user_address_id]])->first();
            $area_tax_rate = @Helper::numberFormat($user_address_data->area->rate);
            $grand_total_amount = @Helper::numberFormat($grand_total_amount + $area_tax_rate);
        }

        return response()->json(['message' => '', 'coupon_code_price' => @Helper::numberFormat($coupon_code_price), 'delivery_fee' => @Helper::numberFormat($area_tax_rate), 'grand_total_amount' => @Helper::numberFormat($grand_total_amount)]);
    }

    public function applyCoupon(Request $request)
    {
        $user_id = $this->user_id;
        $code = $request->coupon_code;
        $user_address_id = $request->user_address_id;
        $purchase_type = $request->purchase_type;
        //For buy-now
        $is_buy_now = $request->is_buy_now;

        $promocode_data = Promocode::where('promo_name', $code)->where('status', 1)->first();
        $percentage = '';
        $code_id = '';
        $coupon_code_price = '';
        $area_tax_rate = '';
        $grand_total_amount = '';
        $tax_amount = 0;
        $couponPercentage = "";
        if ($promocode_data == "") {
            $msg = @Helper::language('Invalid_coupon_code');
        } elseif ($promocode_data->start_date >= Carbon::now()) {
            $msg =  @Helper::language('this_coupon_code_is_currently_not_active');
        } elseif (date('Y-m-d') > $promocode_data->end_date) {
            $msg =  @Helper::language('this_coupon_code_is_expired');
        } else {
            $couponPercentage = $promocode_data->discount_percentage;
            $code_id = $promocode_data->id;
            $msg =  @Helper::language('coupon_code_apply_successfully');

            if ($is_buy_now == 1) {
                $variantIds = array($request->pvariant_Ids);
            } else {
                $cartData = Cart::select(DB::raw('group_concat(product_variant_id) as variantIds'))->where('user_id', $user_id)->groupBy('user_id')
                    ->where('status', 1)
                    ->first();
                $variantIds = explode(',', $cartData->variantIds);
            }

            $productData = ProductVariants::getProductDetalsBasedOnVariant()->with('cart')->whereIn('id', $variantIds)->get();

            $product_discounted_price = 0;
            $original_price = 0;
            $total_discount_price = 0;
            $is_product_discount[] =  false;
            foreach ($productData as $result) {
                if ($is_buy_now == 1) {
                    $org_price = @$result->variant_price ? ($result->variant_price * $request->buy_quantity) : 0;
                    $original_price += $org_price;
                    $product_discounted_price = @$result->variant_discounted_price ? ($result->variant_discounted_price * $request->buy_quantity) : 0;
                } else {
                    $org_price = @$result->variant_price ? ($result->variant_price *  Helper::getUserCartQuantity($result->id, $user_id)) : 0;
                    $original_price += $org_price;
                    $product_discounted_price = @$result->variant_discounted_price ? ($result->variant_discounted_price * Helper::getUserCartQuantity($result->id, $user_id)) : 0;
                }

                if ($result->variant_discounted_price != '' && $result->variant_discounted_price != 0.00) {
                    $total_discount_price += ($org_price - $product_discounted_price);
                    $is_product_discount[] = true;
                }
            }
            $total_products_price = @Helper::numberFormat($original_price);

            if (in_array(true, $is_product_discount)) {
                $grand_total_amount =  ($total_products_price -  $total_discount_price);
            } else {
                $grand_total_amount =  $total_products_price;
            }

            $coupon_code_price = ($couponPercentage / 100) * $grand_total_amount;
            $coupon_code_price = @Helper::numberFormat($coupon_code_price);
            $grand_total_amount = @Helper::numberFormat($grand_total_amount - $coupon_code_price);

            if (Helper::Settings('tax') != 0) {
                $tax = (Helper::Settings('tax') / 100) * $grand_total_amount;
                $tax_amount =  @Helper::numberFormat($tax);
                $grand_total_amount = @Helper::numberFormat($grand_total_amount + $tax_amount);
            }

            if ($purchase_type == 1) {
                if (!empty($user_address_id)) {
                    $user_address_data = UserAddress::with(['country', 'region', 'area'])->where([['user_id', $user_id], ['status', 1], ['id', $user_address_id]])->first();
                    $area_tax_rate = @Helper::numberFormat($user_address_data->area->rate);
                    $grand_total_amount = @Helper::numberFormat($grand_total_amount + $area_tax_rate);
                }
            }
        }
        $data = ['message' => $msg, 'coupon_percentage' => $couponPercentage, 'coupon_code_price' => @Helper::numberFormat($coupon_code_price), 'delivery_fee' => @Helper::numberFormat($area_tax_rate), 'grand_total_amount' => @Helper::numberFormat($grand_total_amount), 'tax_amount' => @Helper::numberFormat($tax_amount), 'code_id' => $code_id];
        // dd($data);
        return response()->json($data);
    }

    public function storePlaceOrder(Request $request)
    {
        // dd($request->all());
        $user_id = $this->user_id;
        $user_address_id = $request->user_address_id;
        $payment_method = $request->payment_method;
        $purchase_type = $request->purchase_type;
        $delivery_charge = $request->delivery_charge;

        $store_location_id = $request->store_location_id;
        $coupon_code_id = $request->coupon_code_id;
        $coupon_percentage = $request->coupon_percentage;
        $tax = $request->tax;
        $buy_org_price = $request->buy_org_price;
        $buy_discounted_price = $request->buy_discounted_price;

        //If User apply poromo code
        if (!empty($coupon_code_id)) {
            $promocode_data = Promocode::where('status', 1)->where('id', $coupon_code_id)->first();
            if (!empty($promocode_data)) {
                if ($promocode_data->discount_percentage != $coupon_percentage) {
                    return response()->json(['error' => true, 'message' => @Helper::language('something_went_wrong'), 'type' => 'coupon']);
                }
            } else {
                return response()->json(['error' => true, 'message' => @Helper::language('something_went_wrong'), 'type' => 'coupon']);
            }
        }

        $delivery_address = '';
        if (!empty($user_address_id) && $purchase_type == 1) {
            $user_address_data = UserAddress::with(['country', 'region', 'area'])->where([['user_id', $user_id], ['status', 1], ['id', $user_address_id]])->first();

            $status = $user_address_data->area->status;
            if ($status == 1) {
                if ($user_address_data->area->rate != $delivery_charge) {
                    return response()->json(['error' => true, 'message' => @Helper::language('something_went_wrong_in_delivery_fee'), 'type' => 'address']);
                }
            } else {
                return response()->json(['error' => true, 'message' => @Helper::language('Something_went_wrong_in_the_delivery_address'), 'type' => 'address']);
            }
            $delivery_address = "";
            ($user_address_data->name) ? $delivery_address .= $user_address_data->name : '';
            ($user_address_data->address) ? $delivery_address .= ',| ' . $user_address_data->address : '';
            ($user_address_data->country->name) ? $delivery_address .= ',| ' . $user_address_data->country->name : '';
            ($user_address_data->region->title) ? $delivery_address .= ',| ' . $user_address_data->region->title : '';
            ($user_address_data->area->title) ? $delivery_address .= ',| ' . $user_address_data->area->title : '';
            ($user_address_data->phone) ? $delivery_address .= ',| +' . @$user_address_data->phonecode . ' ' . @$user_address_data->phone : '';
            ($user_address_data->city) ? $delivery_address .= ',| ' . @$user_address_data->city . ' ' . @$user_address_data->city : '';
            ($user_address_data->zip_code) ? $delivery_address .= ',| ' . @$user_address_data->zip_code . ' ' . @$user_address_data->zip_code : '';
        }
    //    print_r( $delivery_address);
    //    die;
        //tax
        if (!empty(Helper::Settings('tax')) && $tax != Helper::Settings('tax')) {
            return response()->json(['error' => true, 'message' => @Helper::language('something_went_wrong'), 'type' => 'tax']);
        }

        $store_id = '';
        $store_address = '';
        if ($store_location_id != "" && $purchase_type == 2) {

            $store_data = DB::table('store_details')->where('id', $store_location_id)->where('status', 1)->first();
            if (empty($store_data)) {
                return response()->json(['error' => true, 'message' => @Helper::language('something_went_wrong'), 'type' => 'store_inactive']);
            }
            $store_id = $store_data->id;
            $store_phone_number =

                $contactNumber = '';
            if ($store_data->phone_code) {
                $contactNumber .= '+' . $store_data->phone_code . ' ';
            }
            if ($store_data->contact_number) {
                $contactNumber .= $store_data->contact_number;
            }
            $store_address = $store_data->store_name . ',| ' . $store_data->address . ',| ' . $contactNumber;
        }

        //For buy-now
        $is_buy_now = $request->is_buy_now;
        if ($is_buy_now == 1) {
            $variantIds = array($request->pvariant_Ids);
        } else {
            $cartData = Cart::select(DB::raw('group_concat(product_variant_id) as variantIds'))->where('user_id', $user_id)->groupBy('user_id')->where('status', 1)->first();
            if (empty($cartData)) {
                return response()->json(['error' => true, 'message' => @Helper::language('something_went_wrong'), 'type' => 'cart']);
            }
            $variantIds = explode(',', $cartData->variantIds);
        }

        $productData = ProductVariants::getProductDetalsBasedOnVariant()->with('cart')->whereIn('id', $variantIds)->get();

        /// dd($productData);
        $pcount = count($productData);
        $vcount = count($variantIds);
        // dd($pcount,$vcount);
        if ($vcount != $pcount) {
            return response()->json(['error' => true, 'message' => @Helper::language('something_went_wrong'), 'type' => 'product']);
        }

        $is_product_active = array();
        $check_stock = array();
        $is_product_price_change = array();
        foreach ($productData as $variant) {
            if ($variant->get_product_details->status == 1 && $variant->get_product_details->get_category->status == 1 && $variant->get_product_details->get_subcategory->status == 1 && $variant->get_product_details->get_brand_details->status == 1) {
                $is_product_active[] =  false;
            }
            if ($is_buy_now == 1) {
                $cart_qty = $request->buy_quantity;
                if ($variant->variant_price != $buy_org_price || $variant->variant_discounted_price != $buy_discounted_price) {
                    $is_product_price_change[] = true;
                }
            } else {
                $cart_qty = Helper::getUserCartQuantity($variant->id, $user_id);
                $cart_info = Cart::where(['product_variant_id' => $variant->id, 'user_id' => $user_id, 'status' => 1, 'order_type' => 1])->first();
                if ($variant->variant_price != $cart_info->product_price || $cart_info->offer_price != $variant->variant_discounted_price) {
                    $is_product_price_change[] = true;
                }
            }

            //This for both cart & buy now
            if ($variant->available_qty < $cart_qty) {
                $check_stock[] = true;
            }
        }

        if (in_array('true', $is_product_price_change)) {
            return response()->json(['error' => true, 'message' => @Helper::language('something_went_wrong'), 'type' => 'product_price']);
        }

        if (in_array('true', $check_stock)) {
            return response()->json(['error' => true, 'message' => @Helper::language('something_went_wrong'), 'type' => 'stock']);
        }

        if (in_array('false', $is_product_active)) {
            return response()->json(['error' => true, 'message' => @Helper::language('something_went_wrong'), 'type' => 'product_s']);
        }

        $userData = \DB::table('main_users')->where('id', $user_id)->where('status', 1)->first();
        ///dd($userData);
        $order_uid = uniqid();
        $order = new Order();
        $order->uniqid = $order_uid;
        $order->user_id = $user_id;
        $order->supplier_id = $store_id;
        $order->order_id = $this->geneateOrderId();
        $order->delivery_address = $delivery_address;
        $order->order_type = $purchase_type;
        $order->order_date = date('Y-m-d H:i:s');
        $order->order_time = date('Y-m-d H:i:s');
        $order->order_status = 1; //Pending
        if ($payment_method == 1) {
            $order->status = 2;
        } else {
            $order->status = 1;
        }
        $order->save();

        $tracking_id = uniqid();
        $order_tracking = new OrderTracking();
        $order_tracking->order_id = $order->id;
        $order_tracking->uniqid = $tracking_id;
        $order_tracking->order_status = 1;
        $order_tracking->status = 1;
        $order_tracking->save();

        $order_info = new OrderInfo();
        $order_info->order_id = $order->id;
        if ($purchase_type == 1) {
            $order_info->country_id = $user_address_data->country_id;
            $order_info->region_id = $user_address_data->region_id;
            $order_info->area_id = $user_address_data->area_id;
        }
        $order_info->customer_name = $userData->first_name . ' ' . $userData->last_name;
        $order_info->customer_mobile = $userData->phone_code . ' ' . $userData->phone;
        $order_info->customer_email = $userData->email;
        $order_info->customer_country = ($userData->country_code) ?: '';
        $order_info->order_from = '1';
        if ($purchase_type == 2) {
            $order_info->store_pickup_address = $store_address;
        }
        $order_info->save();

        $original_price = 0;
        $total_discount_price = 0;
        $product_discount_price = 0;
        $is_product_discount[] =  false;
        foreach ($productData as $result) {
            if ($is_buy_now == 1) {
                $cart_qty = $request->buy_quantity;
                $variant_orginal_price = $buy_org_price;
                $variant_offer_price = $buy_discounted_price;
            } else {
                $cart_qty = Helper::getUserCartQuantity($result->id, $user_id);
                //using for variant new price
                $cart_info = Cart::where(['product_variant_id' => $result->id, 'user_id' => $user_id, 'status' => 1, 'order_type' => 1])->first();
                $variant_orginal_price = $cart_info->product_price;
                $variant_offer_price = $cart_info->offer_price;
            }

            $product_unit = Helper::getUnitById($result->variant_uof);
            //$product_total_price = ($cart_qty * $result->variant_discounted_price);
            $order_detail = new OrderDetails();
            $order_detail->order_id = @$order->id;
            $order_detail->product_id = $result->get_product_details->id;
            $order_detail->variant_id = @$result->id;
            $order_detail->customer_id = $user_id;
            $order_detail->product_original_amount = $variant_orginal_price;
            $order_detail->product_total_amount = $variant_offer_price;
            $order_detail->quantity = $cart_qty;
            $order_detail->variant_size = $result->variant_size;
            $order_detail->variant_unit = $result->variant_uof;
            $order_detail->status = 1;
            $order_detail->save();

            // $org_price = @$result->variant_price ? ($result->variant_price * $cart_qty) : 0;
            // $original_price += $org_price;      
            // $product_discount_price = @$result->variant_discounted_price ? ($result->variant_discounted_price * $cart_qty) : 0;
            // if($result->variant_discounted_price !='' && $result->variant_discounted_price != 0.00){ 
            //     $total_discount_price += ($org_price - $product_discount_price);
            //     $is_product_discount[] = true;
            // }

            $org_price = @$variant_orginal_price ? ($variant_orginal_price * $cart_qty) : 0;
            $original_price += $org_price;
            $product_discount_price = @$variant_offer_price ? ($variant_offer_price * $cart_qty) : 0;
            if ($variant_offer_price  != '' && $variant_offer_price != '0') {
                $total_discount_price += ($org_price - $product_discount_price);
                $is_product_discount[] = true;
            }

            if ($payment_method == 3) {
                $available_qty = $result->available_qty - $cart_qty;
                $sold_qty = $result->sold_qty + $cart_qty;

                ProductVariants::where('id', $result->id)->update(array('available_qty' => $available_qty, 'sold_qty' => $sold_qty));
            }
        }


        $total_products_price = $original_price;
        if (in_array(true, $is_product_discount)) {
            $product_sub_total_amount = ($total_products_price -  $total_discount_price);
            $grand_total_amount =  ($total_products_price -  $total_discount_price);
        } else {
            $product_sub_total_amount = $total_products_price;
            $grand_total_amount =  $total_products_price;
        }

        $coupon_code_price = '';
        $promo_title = '';
        $couponPercentage = '';

        if (!empty($promocode_data)) {
            $promo_title = $promocode_data->promo_name;
            $couponPercentage = $promocode_data->discount_percentage;
            $coupon_code_price = @Helper::numberFormat(($couponPercentage / 100) * $grand_total_amount);
            $sub_total_amount = ($grand_total_amount - $coupon_code_price);
            OrderInfo::where('order_id', $order->id)
                ->update(array(
                    'promocode_name' => $promo_title,
                    'promocode_percentage' => $couponPercentage
                ));
            $grand_total_amount = $sub_total_amount;
        }

        //Tax 
        if (Helper::Settings('tax') != 0 && $tax != "") {
            $tax  = ($tax / 100) * $grand_total_amount;
            $tax_amount =  @Helper::numberFormat($tax);
            Order::where('id', $order->id)->update(array('tax' => $tax_amount));
            $grand_total_amount = @Helper::numberFormat($grand_total_amount + $tax_amount);
        }

        if (!empty($user_address_id) && $purchase_type == 1) {
            $area_tax_rate = @Helper::numberFormat($user_address_data->area->rate);
            $grand_total_amount = @Helper::numberFormat($grand_total_amount + $area_tax_rate);
            OrderInfo::where('order_id', $order->id)->update(array('delivery_fee' => $area_tax_rate));
        }

        $transactions = new Transactions();
        $transactions->trans_no = $this->geneateTranscationId();
        $transactions->user_id = $user_id;
        $transactions->order_id = @$order->id;
        $transactions->payment_type = $payment_method;
        $transactions->payment_status = '1';
        $transactions->amount = $grand_total_amount;
        $transactions->transaction_date = date('Y-m-d H:i:s');
        if ($payment_method == 1) {
            $transactions->status = 2;
        } else {
            $transactions->status = 1;
        }
        $transactions->save();

        //  $response = (new \Helper)->send_notification_FCM($remember_token, $title, $message, $device_type);
        // $response = (new \Helper)->sendNotification($device_token, $title, $message, $device_type);
        //300+30 = 330

        //dd($product_sub_total_amount);

        $updatepsw = Order::where('user_id', $user_id)->where('id', $order->id)
            ->update(array(
                'total_amount' => $product_sub_total_amount,
                'payable_amount' => $grand_total_amount,
                'discount_amount' => $coupon_code_price
            ));

        if ($payment_method == 1) {
            $grand_total_amount = $grand_total_amount;
            $redirectUrl = route('orderSuccessCard', ['userid' => $user_id, 'orderid' => $order->id, 'amount' => $grand_total_amount]);
            $backUrl = url('/');
            $xmlPayload = '<?xml version=\"1.0\" encoding=\"utf-8\"?><API3G><CompanyToken>4CF16A78-27EA-47A7-B1D4-6E52343C8DC1</CompanyToken><Request>createToken</Request><Transaction><PaymentAmount>' . $grand_total_amount . '</PaymentAmount><PaymentCurrency>GHS</PaymentCurrency><CompanyRef>49FKEOA</CompanyRef><RedirectURL>' . $redirectUrl . '</RedirectURL><BackURL>'.$backUrl.'</BackURL><CompanyRefUnique>0</CompanyRefUnique><PTL>5</PTL>
            </Transaction><Services><Service><ServiceType>87197</ServiceType><ServiceDescription>Food And Beverages</ServiceDescription><ServiceDate>'.date('Y-m-d H:i:s').'</ServiceDate></Service></Services>
            </API3G>';
            
        $getToken = \Helper::createToken($xmlPayload, $grand_total_amount, $redirectUrl, $backUrl,$user_id,$user_address_id);
         //dd($getToken);
        $result = json_decode(json_encode($getToken), true);

            // dd($getToken);
            $result = json_decode(json_encode($getToken), true);
            if (@$result['original']['error']) {
                return response()->json(['error' => true, 'message' => @Helper::language('something_went_wrong'), 'type' => 'payment_error']);
            }

            if (@$result['original']['token']) {
                if ($is_buy_now != 1) {
                    $updatepsw = Cart::where('user_id', $user_id)->update(array('status' => 2));
                }
                $token = $result['original']['token'][0];
                $paymentUrl = 'https://secure.3gdirectpay.com/payv3.php?ID=' . $token;
                // dd($paymentUrl);
                return response()->json(['success' => true, 'redirect_url' => $paymentUrl]);
            }
        }

        $userData = DB::table('main_users')->where('id', $user_id)->first();
        $title = "Online Order Confirm";
        $message = "Online Order Confirm";
        $remember_token = "fYPZqDsO90pgmZAzTKD0ow:APA91bEF6Pv3waTLBb8lRSUCrjz_M3Vxf14zF3IDHBckRoI79Ojw66aRbuDNhuHWT21qsPYwhOvXxGhILv-nJ0ZCNWzEEuo2tWQ1pDULgeBkPPoAbPaV6ulPJ0W1H8zhA2IcPn8zHl8P";
        $device_token = $userData->device_token;
        // echo "<pre>";print_r($device_token);exit();
        $device_type = 1;

        $notification = new Notification();
        $notification->order_id = @$order->id;
        $notification->sender_id = @$user_id;
        $notification->receiver_id = @$user_id;
        $notification->notification_type = 1;
        $notification->title = @$title;
        $notification->message = @$message;
        $notification->is_read = 0;
        $notification->save();


        
        $admin_notification = new AdminNotifications();
        $admin_notification->order_id = @$order->id;
        $admin_notification->sender_id = @$user_id;
        $admin_notification->receiver_id = @$user_id;
        $admin_notification->notification_type = 1;
        $admin_notification->title = @$title;
        $admin_notification->message = @$message;
        $admin_notification->is_read = 0;
        $admin_notification->save();

        
        // $response = (new \Helper)->send_notification_FCM($remember_token, $title, $message, $device_type);
        // $response = (new \Helper)->sendNotification($device_token, $title, $message, $device_type);

        $this->sendOrderConfirmationEmail($user_id, $order);

        if ($is_buy_now != 1) {
            $updatepsw = Cart::where('user_id', $user_id)->update(array('status' => 2));
        }

        return response()->json(['success' => true, 'order_id' => Helper::encodeUrl($order->id)]);
    }
}
