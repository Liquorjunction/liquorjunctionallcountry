<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Cart;
use App\Models\Label;
use App\Models\Setting;
use App\Models\MainUser;
use App\Models\EmailTemplate;
use App\Models\UserAddress;
use App\Models\Order;
use App\Models\OrderInfo;
use App\Models\OrderTracking;
use App\Models\OrderDetails;
use App\Models\Product;
use App\Models\Transactions;
use App\Models\UsersPayments;
use App\Models\Notification;
use App\Models\ProductVariants;
use App\Models\Promocode;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use App\Models\AdminNotifications;
use Mail;
use Hash;
use Helper;
use Auth;
use DB;
use Carbon\Carbon;

class CheckoutController extends Controller
{
    public function geneateOrderId()
    {
        $uid = Order::orderBy('created_at', 'DESC')->first();
        if ($uid && $uid->id != null) {
            $temp_uid = (int)str_replace('LQ', '', $uid->id) + 1;
            $temp_uid = str_pad($temp_uid, 6, "0", STR_PAD_LEFT);
        } else {
            $temp_uid = 1;
            $temp_uid = str_pad($temp_uid, 6, "0", STR_PAD_LEFT);
        }
        return 'LQOID' . $temp_uid;
    }

    public function geneateTranscationId()
    {
        $uid = Transactions::orderBy('created_at', 'DESC')->first();
        if ($uid && $uid->id != null) {
            $temp_uid = (int)str_replace('LQTC', '', $uid->id) + 1;
            $temp_uid = str_pad($temp_uid, 6, "0", STR_PAD_LEFT);
        } else {
            $temp_uid = 1;
            $temp_uid = str_pad($temp_uid, 6, "0", STR_PAD_LEFT);
        }
        return 'LQTC' . $temp_uid;
    }

    public function sendOrderConfirmationEmail($user_id, $order)
    {
            $order_details = OrderDetails::where('order_id', $order->id)->get(); // Get all order details
    $transactions = Transactions::where('order_id', $order->id)->first();
    $order_info = OrderInfo::where('order_id', $order->id)->first();
      $storePickupAddress = $order_info->store_pickup_address ?? 'Not provided';
// print_r($order_info);
// die;
    // Fetch customer details
    $customerDetails = DB::table('main_users')->find($user_id);
    $setting = Setting::find(1);
    $templateId = 17; // Determine the appropriate template ID
    $emailDetail = EmailTemplate::find($templateId);
    $fromEmail = env('MAIL_FROM_ADDRESS', 'info@liquorjunctionghana.com'); 
    $sendEmail = $customerDetails->email;

    // Prepare email data
    $data = [
        'user_name' => $customerDetails->first_name,
        'sendname' => $customerDetails->first_name,
        'sendemail' => $customerDetails->email,
        'id' => $templateId,
        'order' => $order,
        'order_status' => "Place Order",
        'from_email' => config('mail.from.address'),
         'store_pickup_address' => $storePickupAddress,
    ];

    $order_amount = Order::with('transcations')->where('id', $order->id)->first();

    try {
        // Send email to customer
        Mail::send('emails.orderstatuschanged', $data, function ($message) use ($data,  $emailDetail) {
            $message->to($data['sendemail'], 'Liquor')->subject($emailDetail->subject);
            $message->from($data['from_email'], $emailDetail->title);
        });

        // Send email to admin
        $adminEmail = 'info@liquorjunctionghana.com';
        $adminSubject = 'New Order Received';

        if ($order->order_type == 1) {
                        $order_type_name = "Online Order";
                    } elseif ($order->order_type == 2) {
                        $order_type_name = "In-store";
                    } elseif ($order->order_type == 3) {
                        $order_type_name = "Purchase Order";
                    } else {
                        $order_type_name = "Unknown Order Type";
                    }
            
                    if ($transactions->payment_type == 1) {
                        $payment_type_name = "Momo Pay";
                    } elseif ($transactions->payment_type == 2) {
                        $payment_type_name = "Card (Debit/Credit)";
                    } elseif ($transactions->payment_type == 3) {
                        $payment_type_name = "Cash on Delivery";
                    } else {
                        $payment_type_name = "Unknown Payment Type";
                    }

                    if ($order_info) {
                        if ($order_info->order_from == 1) {
                            $order_type_from = 'Web';
                        } elseif ($order_info->order_from == 2) {
                            $order_type_from = 'Android';
                        } elseif ($order_info->order_from == 3) {
                            $order_type_from = 'iOS';
                        } else {
                            $order_type_from = 'Unknown Source';
                        }
                    } else {
                        $order_type_from = 'Unknown Source';
                    }
        // Initialize the admin email content with the basic details
        $adminEmailContent = "
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; }
        .container { width: 100%; padding: 20px; }
        .content { background-color: #f9f9f9; padding: 15px; border-radius: 5px; }
        .header { font-size: 18px; font-weight: bold; margin-bottom: 90px; }
        .item { margin-bottom: 10px; display: flex; }
        .label { font-weight: bold; width: 150px; }
        .value { margin-left: 10px; flex: 1; }
        .table { width: 100%; border-collapse: collapse;}
        .table th, .table td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        .table th { background-color: #f2f2f2; }
        .total-row { font-weight: bold; }
        .amount-cell { text-align: right; }
        br { display: none; } 
    </style>
</head>
<body>
    <div class='container'>
        <div class='content'>
            <div class='header'><b>A new order has been received.</b></div>
            <div class='item'><span class='label'><b>Customer Details:</b></span></div>
            <div class='item'><span class='label'>Name:</span>  <span class='value'>{$customerDetails->first_name} {$customerDetails->last_name}</span></div>
            <div class='item'><span class='label'>Email:</span>  <span class='value'>{$customerDetails->email}</span></div>
            <div class='item'><span class='label'>Phone:</span>  <span class='value'>+{$customerDetails->phone_code}{$customerDetails->phone}</span></div>";

        // Conditionally display the delivery address
        if (!empty($storePickupAddress) && $storePickupAddress !== 'Not provided') {
            $adminEmailContent .= "
            <div class='item'><span class='label'><b>Store Address:</b></span>  <span class='value'>{$storePickupAddress}</span></div>";
        } else {
            $adminEmailContent .= "
            <div class='item'><span class='label'>Delivery Address:</span>  <span class='value'>{$order->delivery_address}</span></div>";
        }

        $adminEmailContent .= "
            <div class='item'><span class='label'><b>Order Details:</b></span></div>
            <div class='item'><span class='label'>Order ID:</span>  <span class='value'>{$order->order_id}</span></div>
            <div class='item'><span class='label'>Order Type:</span>  <span class='value'>{$order_type_name}</span></div>
            <div class='item'><span class='label'>Order From:</span>  <span class='value'>{$order_type_from}</span></div>
            <div class='item'><span class='label'>Order Date:</span>  <span class='value'>{$order->order_date}</span></div>
            <div class='item'><span class='label'>Order Time:</span>  <span class='value'>{$order->order_time}</span></div>
            <div class='item'><span class='label'>Delivery Status:</span>  <span class='value'>" . ($order->order_status == 1 ? 'Pending' : 'Other') . "</span></div>
            <div class='item'><span class='label'>Payment Method:</span>  <span class='value'>{$payment_type_name}</span></div>
            <div class='item' style='margin-bottom: 0;'>
                 <span class='label'><b>Product Details:</b></span>
           </div>
            <table class='table'>
                <tr>
                    <th style='padding: 5px;'>Product Name</th>
                    <th style='padding: 5px;'>Product Size</th>
                    <th style='padding: 5px;'>Qty</th>
                    <th style='padding: 5px;' class='amount-cell'>Amount</th>
                    <th style='padding: 5px;' class='amount-cell'>Total</th>
                </tr>";

        // Loop through each product in the order
        foreach ($order_details as $order_detail) {
            $product = Product::where('id', $order_detail->product_id)->first();
            $total_amount = $order_detail->quantity * $order_detail->product_original_amount;

            $adminEmailContent .= "
            <tr>
                <td style='padding: 10px;'>{$product->product_name}</td>
                <td style='padding: 10px;'>{$order_detail->variant_size}ML</td>
                <td style='padding: 15px;'>{$order_detail->quantity}</td>
                <td style='padding: 10px;' class='amount-cell'>{$order_detail->product_original_amount} GH₵</td>
                <td style='padding: 10px;' class='amount-cell'>{$total_amount} GH₵</td>
            </tr>";
        }

        // Add subtotal, discount, tax, delivery fee, and total amount
        $adminEmailContent .= "
        <tr class='total-row'>
            <td style='padding: 10px;' colspan='7'>Sub Amount</td>
            <td style='padding: 10px;' class='amount-cell'>{$order_amount->total_amount} GH₵</td>
        </tr>
 <tr class='total-row'>
            <td style='padding: 10px;' colspan='7'>Discount Amount</td>
            <td style='padding: 10px;' class='amount-cell'>- {$order_amount->discount_amount} GH₵ ({$order_info->promocode_name})</td>
        </tr>
        <tr class='total-row'>
            <td style='padding: 10px;' colspan='7'>Tax</td>
            <td style='padding: 10px;' class='amount-cell'>{$order_amount->tax} GH₵</td>
        </tr>
        <tr class='total-row'>
            <td style='padding: 10px;' colspan='7'>Delivery Fee</td>
            <td style='padding: 10px;' class='amount-cell'>{$order_info->delivery_fee} GH₵</td>
        </tr>
        <tr class='total-row'>
            <td style='padding: 10px;' colspan='7'>Total Amount</td>
            <td style='padding: 10px;' class='amount-cell'>{$order_amount->payable_amount} GH₵</td>
        </tr>
            </table>
        </div>
    </div>
</body>
</html>";
// print_r( $adminEmailContent);
// die;

        Mail::raw($adminEmailContent, function ($message) use ($adminEmail, $adminSubject) {
            $message->to($adminEmail)
                ->subject($adminSubject)
                ->from(env('MAIL_FROM_ADDRESS'), env('MAIL_FROM_NAME')); // Ensure this is properly configured in your .env file
        });

    } catch (\Throwable $th) {
        // Log the error for debugging
        \Log::error('Email sending failed: ' . $th->getMessage());
        return response()->json(['success' => false, 'msg' => 'Something went wrong while sending email.']);
    }
        // $customerDetails = DB::table('main_users')->find($user_id);
        // $setting = Setting::find(1);
        // $templateId = 17; // You should determine the appropriate template ID
        // $emailDetail = EmailTemplate::find($templateId);
        // $fromEmail = $setting['mail_username'];
        // $logo = asset('assets/dashboard/images/Logo/logo.png');
        // $sendEmail = $customerDetails->email;

        // $data = [
        //     'user_name' => $customerDetails->first_name,
        //     'sendname' => $customerDetails->first_name,
        //     'sendemail' => $sendEmail,
        //     'id' => $templateId,
        //     'order' => $order,
        //     'order_status' => "Place Order",
        //     'from_email' => $fromEmail,
        // ];
        // $message = "Place Order";
        // $ismail = $this->order_success_email($customerDetails->first_name,$customerDetails->first_name,$sendEmail,$order, $message);


        // try {
        //     Mail::send('emails.orderstatuschanged', $data, function ($message) use ($data, $emailDetail) {
        //         $message->to($data['sendemail'], 'Liquor')->subject($emailDetail->subject);
        //         $message->from($data['from_email'], $emailDetail->title);
        //     });
        // } catch (\Throwable $th) {
        //     return response()->json(['success' => false, 'msg' => 'something went wrong.']);
        // }
    }
    
      public function order_success_email($user_name,$sendname,$sendemail,$order, $order_status)
    {
        $setting = Setting::find(1);
        $from_email = $setting['mail_no_replay'];
        $emailtemp = Emailtemplate::find('17');
        // echo "<pre>";print_r($setting->toArray());exit();
        // $from_email = $setting['from_email'];
        $data = array('user_name'=>$user_name,'sendname'=>$sendname,'sendemail' => $sendemail, 'order' => $order, 'order_status' => $order_status, 'id' => '17', 'from_email' => $from_email, 'support_name' => $setting['support_name'], 'title' => $emailtemp['title'], 'subject' => $emailtemp['subject']);

        Mail::send('emails.orderstatuschanged', $data, function ($message) use ($data) {

            $message->to($data['sendemail'], $data['title'])->subject($data['subject']);
            //$message->to('manoj.vrinsofts@gmail.com', 'Upskild')->subject('Password has been reset succesfully!');

            $message->from($data['from_email'], $data['support_name']);
        });
    }


    public function applyCouponCodeById($id, $type)
    {

        if ($id != "") {
            if ($type == 2) {
                $promocode_data = Promocode::where('promo_name', $id)->where('status', 1)->first();
            } else {
                $promocode_data = Promocode::where('id', $id)->where('status', 1)->first();
            }

            if ($promocode_data == "") {
                $response = [
                    'code'  => strval(0),
                    'message' => 'invalid_coupon_code'
                ];
            } elseif ($promocode_data->start_date >= Carbon::now()) {
                $response = [
                    'code'  => strval(0),
                    'message' => 'coupon_code_currently_not_active'
                ];
            } elseif (date('Y-m-d') > $promocode_data->end_date) {
                $response = [
                    'code'  => strval(0),
                    'message' => 'coupon_code_expired'
                ];
            } else {
                $couponPercentage = $promocode_data->discount_percentage;
                $code_id = $promocode_data->id;
                $response = [
                    'code'  => strval(1),
                    'percentage' =>  strval($couponPercentage),
                    'coupon_id' =>  strval($code_id),
                    'message' => 'coupon_code_applied_successfully',
                ];
            }
        } else {
            $response = [
                'code'  => strval(0),
                'message' => 'not_use'
            ];
        }
        return $response;
    }

    public function appliedCoupon(Request $request)
    {
        $result = [];
        $finalArr = [];
        $validator = \Validator::make($request->all(), [
            'coupon_code' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'code' => strval(0),
                'error' => $validator->messages(),
                'data' => null
            ], 200);
        }


        $coupon_code = $request->coupon_code;
        $coupon_info = $this->applyCouponCodeById($coupon_code, '2');

        $mainResult   =   $coupon_info;
        return response()->json(new \App\Http\Resources\V1\SettingResource($mainResult));
    }

    public function checkout(Request $request)
    {
        
        
        // logger()->info("+++++++++++++++++++++++++++CheckoutController - checkout+++++++++++++++++++++++");
        // logger()->info($request->all());
        
        // logger()->info("-----------------------------------------");
        
        

        $result = [];
        $finalArr = [];
        $validator = \Validator::make($request->all(), [
            'purchase_order_type' => 'required',
            'purchase_type' => 'required',
            'uniqid' => 'required',
            'token' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'code' => strval(0),
                'error' => $validator->messages(),
                'data' => null
            ], 200);
        }

        $response = \App\Helpers\ResponseHelper::userCheckStatus($request->uniqid, $request->token);
        if ($response['code'] != 1) {
            $mainResult   =   $response;
            return response()->json(new \App\Http\Resources\V1\SettingResource($mainResult));
        }
        $userData = DB::table('main_users')->where('uniqid', $request->uniqid)->first();
        $user_id = $userData->id;

        $purchase_type = $request->purchase_type;
        $coupon_id = $request->coupon_id;
        $language = $request->language;
        $store_id =  $request->store_id;
        $user_address_id = $request->user_address_id;
        $purchase_order_type = $request->purchase_order_type;
        
        $is_buy_now = $request->is_buy_now;

        if (!empty($user_address_id) && $purchase_order_type == 1) {
            $validator = \Validator::make($request->all(), [
                'user_address_id' => 'required',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'code' => strval(0),
                    'error' => $validator->messages(),
                    'data' => null
                ], 200);
            }
        }

        if (!empty($store_id) && $purchase_order_type == 2) {
            $validator = \Validator::make($request->all(), [
                'store_id' => 'required',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'code' => strval(0),
                    'error' => $validator->messages(),
                    'data' => null
                ], 200);
            }
        }
        //1 for cart data
        if ($is_buy_now == 0) {
            $userData = DB::table('main_users')->where('uniqid', $request->uniqid)->first();
            $cartData = Cart::select(DB::raw('group_concat(product_variant_id) as variantIds'))->where('user_id', $userData->id)->groupBy('user_id')->where('status', 1)->first();
            
            

            if (empty($cartData)) {
                $result['code']     =  strval(1);
                $result['message']  =  'no_data_found';
                $result['result']   =  NUll;

                $mainResult   =   $result;
                return response()->json(new \App\Http\Resources\V1\SettingResource($mainResult));
            }
            $variantIds = explode(',', $cartData->variantIds);
        }
         
        if ($is_buy_now == 1) {
            $validator = \Validator::make($request->all(), [
                'buy_product_variant_id' => 'required',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'code' => strval(0),
                    'error' => $validator->messages(),
                    'data' => null
                ], 200);
            }
            $variantIds = array($request->buy_product_variant_id);
        }

        // $productData = ProductVariants::getProductDetalsBasedOnVariant()->whereIn('id', $variantIds)->get();
                $productData = ProductVariants::getProductDetalsBasedOnVariant()->with('cart')->whereIn('id', $variantIds)->get();
                
                
                
        //             logger()->info("+++++++++++++++++++++++++++ productData+++++++++++++++++++++++");
        // logger()->info($productData);
        
        // logger()->info("-----------------------------------------");
                


        if (!empty($productData)) {
            $productDataArr = array();
            $org_price = 0;
            $total_discount_price = 0;
            $is_product_discount = [];
            foreach ($productData as $data) {
                if ($is_buy_now == 1) {
                    $variantIds = $request->buy_product_variant_id;
                    $get_qty = $request->buy_quantity;
                } else {
                    $cartInfo = Cart::select('*')->where(['user_id' => $userData->id, 'product_variant_id' => $data->id])->where('status', 1)->first();
                    $get_qty = $cartInfo->quantity;
                }

                if ($request->language == 1) {
                    $title = ($data->get_product_details->product_name_fr) ? $data->get_product_details->product_name_fr : $data->get_product_details->product_name;
                } else {
                    $title = $data->get_product_details->product_name ?: '';
                }
                $product_image = $data->get_product_details->get_product_images->first();
                //$product_variant = $data->get_product_details->get_product_variants->first();

                $product_unit = Helper::getUnitById($data->variant_uof);
                // $product_size =  ($product_variant->variant_size) ? $product_variant->variant_size . ' ' . $product_unit : '' ;
                $product_size =  ($data->variant_size) ? $data->variant_size . ' ' . $product_unit : '';
                if (file_exists(public_path() . '/uploads/product/' . $product_image->image)) {
                    $image_path =  asset('uploads/product/' . $product_image->image);
                } else {
                    $image_path =  asset('assets/frontend/images/image-not-avilable.png');
                }

                $original_price = ($data->variant_price) ? $data->variant_price * $get_qty : 0;
                $org_price += $original_price;

                // if ($data->variant_discounted_price != '' && $data->variant_discounted_price != 0.00) {
                //     $is_product_discount[] = true;
                //     $discounted_price  = $data->variant_discounted_price  * $get_qty;
                //     $total_discount_price += $original_price - $discounted_price;
                // }
              $discounted_price = ($data->variant_discounted_price!='' && $data->variant_discounted_price!=0.00 && $data->variant_discounted_price!=NULL)? $data->variant_discounted_price :$data->variant_price;
if ($discounted_price != '' && $discounted_price != 0.00) {
    $is_product_discount[] = true;
    $discounted_price  = $discounted_price  * $get_qty;
    $total_discount_price += $original_price - $discounted_price;
}
                if ($purchase_type == 1) {
                    $cart_id =  strval(@$cartInfo->id);
                } else {
                    $cart_id = NULL;
                }

                $productDataArr['cart_list'][] = [
                    'product_id' => strval(@$data->get_product_details->id),
                    'product_title' => strval(@$title),
                    'product_size' => strval(@$product_size),
                    'product_image' => $image_path,
                    'product_orignal_price' => strval(@$original_price),
                    'product_discounted_price' => strval(@$discounted_price),
                    'cart_id' => $cart_id,
                    'variant_id' => strval(@$data->id),
                    'product_qty' => $get_qty,
                ];
            }
          

            $total_products_price = $org_price;
            if (in_array(true, $is_product_discount)) {
                $final_amount = ($total_products_price - $total_discount_price);
            } else {
                $final_amount =  $total_products_price;
            }

            $productDataArr['coupon_discount_amount'] = NULL;
            if ($this->applyCouponCodeById($coupon_id, '1')) {
                $coupon_info = $this->applyCouponCodeById($coupon_id, '1');

                if (isset($coupon_info['percentage'])) {
                    $coupon_percentage = $coupon_info['percentage'];
                    $coupon_code_price = ($coupon_percentage / 100) * $final_amount;
                    $coupon_code_price = round($coupon_code_price, 2);
                    $final_amount = round(($final_amount - $coupon_code_price), 2);
                    $productDataArr['coupon_discount_amount'] = strval(@$coupon_code_price);
                }
                $productDataArr['coupon_status'] =  $coupon_info;
            }

            $tax_amount = 0;
            $tax_percentage = 0;
            if (Helper::Settings('tax') != 0) {
                $tax_amount = (Helper::Settings('tax') / 100) * $final_amount;
                $tax_percentage = Helper::Settings('tax');
                $total_amount = $final_amount + $tax_amount;
            } else {
                $total_amount = $final_amount;
            }

            if (!empty($user_address_id) && $purchase_order_type == 1) {
                $user_address_data = UserAddress::with(['country', 'region', 'area'])->where([['user_id', $user_id], ['status', 1], ['id', $user_address_id]])->first();
                $area_tax_rate = round($user_address_data->area->rate, 2);
                $total_amount = round($total_amount + $area_tax_rate, 2);
                $productDataArr['delivery_charge'] = strval(@$area_tax_rate);
            }


            $productDataArr['total_orignal_price'] = strval(@$org_price);
            $productDataArr['total_discount_price'] = strval(@$total_discount_price);
            $productDataArr['tax_percentage'] = strval(@$tax_percentage);
            $productDataArr['tax_amount'] = strval(@$tax_amount);
            $productDataArr['grand_total_amount'] = strval(@$total_amount);


            $result['code']     =    strval(1);
            $result['message']  =   'success';
            $result['result']   =   $productDataArr;
            $mainResult   =   $result;
            return response()->json(new \App\Http\Resources\V1\SettingResource($mainResult));
        } else {
            $result['code']     =  strval(0);
            $result['message']  =  'no_data_found';
            $result['result']   =  [];

            $mainResult   =   $result;
            return response()->json(new \App\Http\Resources\V1\SettingResource($mainResult));
        }
    }

    //If admin change the price and user are going to place order after error price will updated
    public function updateCartProductPriceByVariantIds($variantIds, $user_id)
    {
        if ($variantIds != "") {
            $productData = ProductVariants::whereIn('id', $variantIds)->get();
            foreach ($productData as $result) {

                $cart_data = Cart::where('product_variant_id', $result->id)->where('user_id', $user_id)->where('status', 1)->first();

                $offer_price = $result->variant_discounted_price;
                $varint_pro_price = $result->variant_price;
                if ($result->variant_discounted_price != '' && $result->variant_discounted_price != 0.00) {
                    $tcart_price = @$result->variant_discounted_price ? ($result->variant_discounted_price * $cart_data->quantity) : 0;
                } else {
                    $tcart_price = @$result->variant_price ? ($result->variant_price * $cart_data->quantity) : 0;
                }

                $cart_data->product_price = $varint_pro_price;
                $cart_data->offer_price = $offer_price;
                $cart_data->total_price = $tcart_price;
                $cart_data->save();
            }
        }
    }

    public function placeOrder(Request $request)
    {
        
        
                  logger()->info("#################################placeOrder - CheckoutControlrer #################################");
     logger()->info( $request->all() );
        
        logger()->info("################################# #################################");
        
        
        //echo "string";exit;

        $result = [];
        $finalArr = [];
        $validator = \Validator::make($request->all(), [
            'purchase_order_type' => 'required',
            'purchase_type' => 'required',
            'uniqid' => 'required',
            'token' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'code' => strval(0),
                'error' => $validator->messages(),
                'data' => null
            ], 200);
        }

        $response = \App\Helpers\ResponseHelper::userCheckStatus($request->uniqid, $request->token);
        if ($response['code'] != 1) {
            $mainResult   =   $response;
            return response()->json(new \App\Http\Resources\V1\SettingResource($mainResult));
        }
        $userData = DB::table('main_users')->where('uniqid', $request->uniqid)->first();
        $user_id = $userData->id;
        
        
          logger()->info("#################################       user_id #################################");
     logger()->info( $user_id);
        
        logger()->info("################################# #################################");

        $purchase_type = $request->purchase_type;
        $coupon_id = $request->coupon_id;
        $language = $request->language;
        $store_id =  $request->store_id;
        $user_address_id = $request->user_address_id;
        $purchase_order_type = $request->purchase_order_type;
        $payment_method = $request->payment_method;
        $delivery_charge = $request->delivery_charge;
        $coupon_percentage = $request->coupon_percentage;
        $tax = $request->purchase_tax_percentage;
        $buy_org_price = $request->buy_org_price;
        $buy_discounted_price = $request->buy_discounted_price;
        $buy_quantity = $request->buy_quantity;
        
        $order_from = $request->order_from ? $request->order_from: 2;
        
          $is_buy_now = $request->is_buy_now;

        $delivery_address = '';
        if (!empty($user_address_id) && $purchase_order_type == 1) {
            $validator = \Validator::make($request->all(), [
                'user_address_id' => 'required',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'code' => strval(0),
                    'error' => $validator->messages(),
                    'data' => null
                ], 200);
            }
            $user_address_data = UserAddress::with(['country', 'region', 'area'])->where([['user_id', $user_id], ['status', 1], ['id', $user_address_id]])->first();

            if ($user_address_data->area->status == 1) {
                if ($user_address_data->area->rate != $delivery_charge) {

                    $result['code']     =  strval(0);
                    $result['message']  =  'something_went_wrong';
                    $result['error_type']  =  'address';
                    $result['result']   =  NULL;

                    $mainResult   =   $result;
                    return response()->json(new \App\Http\Resources\V1\SettingResource($mainResult));
                }
            } else {
                $result['code']     =  strval(0);
                $result['message']  =  'something_went_wrong_in_the_delivery_address';
                $result['error_type']  =  'address';
                $result['result']   =  NULL;

                $mainResult   =   $result;
                return response()->json(new \App\Http\Resources\V1\SettingResource($mainResult));
            }
            $delivery_address = "";
            ($user_address_data->name) ? $delivery_address .= $user_address_data->name : '';
            ($user_address_data->address) ? $delivery_address .= ',| ' . $user_address_data->address : '';
            ($user_address_data->country->name) ? $delivery_address .= ',| ' . $user_address_data->country->name : '';
            ($user_address_data->region->title) ? $delivery_address .= ',| ' . $user_address_data->region->title : '';
            ($user_address_data->area->title) ? $delivery_address .= ',| ' . $user_address_data->area->title : '';
            ($user_address_data->phone) ? $delivery_address .= ',| +' . $user_address_data->phonecode . ' ' . $user_address_data->phone : '';
        }


        $store_address = '';
        if (!empty($store_id) && $purchase_order_type == 2) {
            $validator = \Validator::make($request->all(), [
                'store_id' => 'required',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'code' => strval(0),
                    'error' => $validator->messages(),
                    'data' => null
                ], 200);
            }

            if ($store_id != "") {
                $store_data = DB::table('store_details')->where('id', $store_id)->where('status', 1)->first();
                if (empty($store_data)) {
                    $result['code']     =  strval(0);
                    $result['message']  =  'something_went_wrong';
                    $result['error_type']  =  'store_inactive';
                    $result['result']   =  NULL;

                    $mainResult   =   $result;
                    return response()->json(new \App\Http\Resources\V1\SettingResource($mainResult));
                }
                $store_id = $store_data->id;
                $store_address = $store_data->store_name . ',| ' . $store_data->address;
            }
        } else {
            $store_id = "";
        }

        if (!empty(Helper::Settings('tax')) && $tax != Helper::Settings('tax')) {
            $result['code']     =  strval(0);
            $result['message']  =  'something_went_wrong';
            $result['error_type']  =  'tax_percentage';
            $result['result']   =  NULL;

            $mainResult   =   $result;
            return response()->json(new \App\Http\Resources\V1\SettingResource($mainResult));
        }

        if (!empty($coupon_id)) {
            $promocode_data = Promocode::where('status', 1)->where('id', $coupon_id)->first();

            if (empty($promocode_data) || $promocode_data->discount_percentage != $coupon_percentage) {

                $result['code']     =  strval(0);
                $result['message']  =  'something_went_wrong';
                $result['error_type']  =  'coupon';
                $result['result']   =  NULL;

                $mainResult   =   $result;
                return response()->json(new \App\Http\Resources\V1\SettingResource($mainResult));
            }
        }

        //1 for cart data
        if ($is_buy_now == 0) {
            $userData = DB::table('main_users')->where('uniqid', $request->uniqid)->first();
            $cartData = Cart::select(DB::raw('group_concat(product_variant_id) as variantIds'))->where('user_id', $userData->id)->groupBy('user_id')->where('status', 1)->first();

            if (empty($cartData)) {
                $result['code']     =  strval(1);
                $result['message']  =  'no_data_found';
                $result['result']   =  NUll;

                $mainResult   =   $result;
                return response()->json(new \App\Http\Resources\V1\SettingResource($mainResult));
            }
            $variantIds = explode(',', $cartData->variantIds);
        }
        if ($is_buy_now == 1) {
            $validator = \Validator::make($request->all(), [
                'buy_product_variant_id' => 'required',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'code' => strval(0),
                    'error' => $validator->messages(),
                    'data' => null
                ], 200);
            }
            $variantIds = array($request->buy_product_variant_id);
        }

        // $productData = ProductVariants::getProductDetalsBasedOnVariant()->whereIn('id', $variantIds)->get();
         $productData = ProductVariants::getProductDetalsBasedOnVariant()->with('cart')->whereIn('id', $variantIds)->get();

    //           logger()->info("mobile");
    //  logger()->info( $productData );


        $pcount = count($productData);
        $vcount = count($variantIds);

        if ($vcount != $pcount) {
            $result['code']     =  strval(0);
            $result['message']  =  'something_went_wrong';
            $result['error_type']  =  'product';
            $result['result']   =  NULL;

            $mainResult   =   $result;
            return response()->json(new \App\Http\Resources\V1\SettingResource($mainResult));
        }

        $is_product_active = array();
        $check_stock = array();
        $is_product_price_change = array();
        foreach ($productData as $variant) {
            if ($variant->get_product_details->status == 1 && $variant->get_product_details->get_category->status == 1 && $variant->get_product_details->get_subcategory->status == 1 && $variant->get_product_details->get_brand_details->status == 1) {
                $is_product_active[] =  false;
            }
            if ($is_buy_now == 1) {
                $cart_qty = $buy_quantity;
                if ($variant->variant_price != $buy_org_price || $variant->variant_discounted_price != $buy_discounted_price) {
                    $is_product_price_change[] = true;
                }
            } else {
                $cart_qty = Helper::getUserCartQuantity($variant->id, $user_id);
                $cart_info = Cart::where(['product_variant_id' => $variant->id, 'user_id' => $user_id, 'status' => 1])->first();
                //,'order_type'=>1
                if ($variant->variant_price != $cart_info->product_price || $cart_info->offer_price != $variant->variant_discounted_price) {
                    $is_product_price_change[] = true;
                }
            }

            //This for both cart & buy now
            if ($variant->available_qty < $cart_qty) {
                $check_stock[] = true;
            }
        }
        if (in_array('true', $is_product_price_change)) {

            $result['code']     =  strval(0);
            $result['message']  =  'something_went_wrong';
            $result['error_type']  = 'product_price';
            $result['result']   =  NULL;

            $mainResult   =   $result;
            if ($is_buy_now == 1) {
                $this->updateCartProductPriceByVariantIds($variantIds, $user_id);
            }
            return response()->json(new \App\Http\Resources\V1\SettingResource($mainResult));
        }

        if (in_array('true', $check_stock)) {
            $result['code']     =  strval(0);
            $result['message']  =  'something_went_wrong';
            $result['error_type']  =  'stock';
            $result['result']   =  NULL;

            $mainResult   =   $result;
            return response()->json(new \App\Http\Resources\V1\SettingResource($mainResult));
        }

        if (in_array('false', $is_product_active)) {
            return response()->json(['error' => true, 'message' => @Helper::language('something_went_wrong'), 'type' => 'product_active']);

            $result['code']     =  strval(0);
            $result['message']  =  'something_went_wrong';
            $result['error_type']  =  'product_active';
            $result['result']   =  NULL;

            $mainResult   =   $result;
            return response()->json(new \App\Http\Resources\V1\SettingResource($mainResult));
        }
        $order_custom_id = $this->geneateOrderId();
        $order_uid = uniqid();
        $order = new Order();
        $order->uniqid = @$order_uid;
        $order->user_id = @$user_id;
        $order->supplier_id = @$store_id;
        $order->order_id = $order_custom_id;
        $order->delivery_address = @$delivery_address;
        $order->order_type = @$purchase_order_type;
        $order->order_date = date('Y-m-d H:i:s');
        $order->order_time = date('Y-m-d H:i:s');
        $order->order_status = 1; //Pending
        if ($payment_method == 1) {
            $order->status = 2;
        } else {
            $order->status = 1;
        }
        $order->save();

        $tracking_id = uniqid();
        $order_tracking = new OrderTracking();
        $order_tracking->order_id = @$order->id;
        $order_tracking->uniqid = @$tracking_id;
        $order_tracking->order_status = 1;
        $order_tracking->status = 1;
        $order_tracking->save();


        $order_info = new OrderInfo();
        $order_info->order_id = $order->id;
        if ($purchase_order_type == 1) {
            $order_info->country_id = @$user_address_data->country_id;
            $order_info->region_id = @$user_address_data->region_id;
            $order_info->area_id = @$user_address_data->area_id;
        }

        $order_info->customer_name = @$userData->first_name . ' ' . $userData->last_name;
        $order_info->customer_mobile = @$userData->phone_code . ' ' . $userData->phone;
        $order_info->customer_email = @$userData->email;
        $order_info->customer_country = (@$userData->country_code) ?: '';
        $order_info->order_from = $order_from;
        if ($purchase_order_type == 2) {
            $order_info->store_pickup_address = @$store_address;
        }
        $order_info->save();
        
    //           logger()->info("orderInfo");
    //   logger()->info( $order_info );

        $original_price = 0;
        $total_discount_price = 0;
        $product_discount_price = 0;
        $is_product_discount[] =  false;
        foreach ($productData as $variant_product) {
            if ($is_buy_now == 1) {
                $cart_qty = $buy_quantity;
                $variant_orginal_price = $buy_org_price;
                $variant_offer_price = $buy_discounted_price;
            } else {
                $cart_qty = Helper::getUserCartQuantity($variant_product->id, $user_id);
                //using for variant new price
                $cart_info = Cart::where(['product_variant_id' => $variant_product->id, 'user_id' => $user_id, 'status' => 1, 'order_type' => 1])->first();
                $variant_orginal_price = $cart_info->product_price;
                $variant_offer_price = $cart_info->offer_price;
            }

            $product_unit = Helper::getUnitById($variant_product->variant_uof);
            //$product_total_price = ($cart_qty * $result->variant_discounted_price);
            $order_detail = new OrderDetails();
            $order_detail->order_id = @$order->id;
            $order_detail->product_id = @$variant_product->get_product_details->id;
            $order_detail->variant_id = @$variant_product->id;
            $order_detail->customer_id = @$user_id;
            $order_detail->product_original_amount = @$variant_orginal_price;
            $order_detail->product_total_amount = @$variant_offer_price;
            $order_detail->quantity = @$cart_qty;
            $order_detail->variant_size = @$variant_product->variant_size;
            $order_detail->variant_unit = @$variant_product->variant_uof;
            $order_detail->status = 1;
            $order_detail->save();


            $org_price = @$variant_orginal_price ? ($variant_orginal_price * $cart_qty) : 0;
            $original_price += $org_price;
            $product_discount_price = @$variant_offer_price ? ($variant_offer_price * $cart_qty) : 0;
            if ($variant_offer_price  != '' && $variant_offer_price != '0') {
                $total_discount_price += ($org_price - $product_discount_price);
                $is_product_discount[] = true;
            }


            if ($payment_method == 3) {
                $available_qty = @$variant_product->available_qty - $cart_qty;
                $sold_qty = @$variant_product->sold_qty + $cart_qty;
                ProductVariants::where('id', $variant_product->id)->update(array('available_qty' => $available_qty, 'sold_qty' => $sold_qty));
            }
        }


        $total_products_price = $original_price;
        if (in_array(true, $is_product_discount)) {
            $product_sub_total_amount = ($total_products_price -  $total_discount_price);
            $grand_total_amount =  ($total_products_price -  $total_discount_price);
        } else {
            $product_sub_total_amount = $total_products_price;
            $grand_total_amount =  $total_products_price;
        }

        $coupon_code_price = '';
        $promo_title = '';
        $couponPercentage = '';

        if (!empty($promocode_data)) {
            $promo_title = $promocode_data->promo_name;
            $couponPercentage = $promocode_data->discount_percentage;
            $coupon_code_price = ($couponPercentage / 100) * $grand_total_amount;
            $sub_total_amount = ($grand_total_amount - round($coupon_code_price, 2));
            OrderInfo::where('order_id', $order->id)
                ->update(array(
                    'promocode_name' => $promo_title,
                    'promocode_percentage' => $couponPercentage
                ));
            $grand_total_amount = $sub_total_amount;
        }

        //Tax 
        if (Helper::Settings('tax') != 0 && $tax != "") {
            $tax  = ($tax / 100) * $grand_total_amount;
            $tax_amount =  round($tax, 2);
            Order::where('id', $order->id)->update(array('tax' => $tax_amount));
            $grand_total_amount = round(($grand_total_amount + $tax_amount), 2);
        }

        if (!empty($user_address_id) && $purchase_order_type == 1) {
            $area_tax_rate = round($user_address_data->area->rate, 2);
            $grand_total_amount = round($grand_total_amount + $area_tax_rate, 2);
            OrderInfo::where('order_id', $order->id)->update(array('delivery_fee' => $area_tax_rate));
        }


        $transactions = new Transactions();
        $transactions->trans_no = $this->geneateTranscationId();
        $transactions->user_id = $user_id;
        $transactions->order_id = @$order->id;
        $transactions->payment_type = @$payment_method;
        $transactions->payment_status = '1';
        $transactions->amount = @$grand_total_amount;
        $transactions->transaction_date = date('Y-m-d H:i:s');
        if ($payment_method == 1) {
            $transactions->status = 2;
        } else {
            $transactions->status = 1;
        }
        $transactions->save();

        $updatepsw = Order::where('user_id', $user_id)->where('id', $order->id)
            ->update(array(
                'total_amount' => $product_sub_total_amount,
                'payable_amount' => $grand_total_amount,
                'discount_amount' => $coupon_code_price
            ));

        if ($is_buy_now == 0) {
            $updatepsw = Cart::where('user_id', $user_id)->update(array('status' => 2));
        }

        if ($payment_method == 1) {
            $grand_total_amount = $grand_total_amount;
           $redirectUrl = route('orderSuccessCard', ['userid' => $user_id, 'orderid' => $order->id, 'amount' => $grand_total_amount]);
$backUrl = 'https://liquorjunctionghana.com/';
$xmlPayload = '<?xml version="1.0" encoding="utf-8"?><API3G><CompanyToken>4CF16A78-27EA-47A7-B1D4-6E52343C8DC1</CompanyToken><Request>createToken</Request><Transaction><PaymentAmount>' . $grand_total_amount . '</PaymentAmount><PaymentCurrency>GHS</PaymentCurrency><CompanyRef>49FKEOA</CompanyRef><RedirectURL>' . $redirectUrl . '</RedirectURL><BackURL>' . $backUrl . '</BackURL><CompanyRefUnique>0</CompanyRefUnique><PTL>5</PTL></Transaction><Services><Service><ServiceType>87197</ServiceType><ServiceDescription>Food And Beverages</ServiceDescription><ServiceDate>'.date('Y-m-d H:i:s').'</ServiceDate></Service></Services></API3G>';

$getToken = \Helper::createToken($xmlPayload, $grand_total_amount, $redirectUrl, $backUrl,$user_id,$user_address_id);

     logger()->info("+++++++++++++++++++++++++++checkoutMobile - createTokenMobile+++++++++++++++++++++++");
        logger()->info($getToken);
        
        logger()->info("-----------------------------------------");
            $result = json_decode(json_encode($getToken), true);
            if (@$result['original']['error']) {
                $result['code']     =  strval(0);
                $result['message']  =  'something_went_wrong';
                $result['error_type']  =  'payment_failed';
                $result['result']   =  NULL;

                $mainResult   =   $result;
                return response()->json(new \App\Http\Resources\V1\SettingResource($mainResult));
            }

            if (@$result['original']['token']) {
                $token = $result['original']['token'][0];
                $paymentUrl = 'https://secure.3gdirectpay.com/payv3.php?ID=' . $token;
                // dd($paymentUrl);

                $response_data['order_number'] = $order_custom_id;
                $response_data['payment_url'] = $paymentUrl;

                $result['code']     =  strval(1);
                $result['message']  =  'order_sucessfully_placed';
                $result['result']   =  $response_data;
                $result['generate_token']    =  $token;

                $mainResult   =   $result;
                return response()->json(new \App\Http\Resources\V1\SettingResource($mainResult));
            }
        }

        $title = "Liquor";
        $message = "Online Order Confirm";
        $device_token = $userData->device_token;
        $device_type = 1;

        $notification = new Notification();
        $notification->order_id = @$order->id;
        $notification->sender_id = @$user_id;
        $notification->receiver_id = @$user_id;
        $notification->notification_type = 1;
        $notification->title = @$title;
        $notification->message = @$message;
        $notification->is_read = 0;
        $notification->save();
        
                           $admin_notification = new AdminNotifications();
                            $admin_notification->order_id = @$order->id;
                            $admin_notification->sender_id = @$user_id;
                            $admin_notification->receiver_id = @$user_id;
                            $admin_notification->notification_type = 1;
                            $admin_notification->title = @$title;
                            $admin_notification->message = @$message;
                            $admin_notification->is_read = 0;
                            $admin_notification->save();

      //  \Helper::sendNotification($device_token, $title, $message, @$order->id, @$order_custom_id);

        $this->sendOrderConfirmationEmail($user_id, $order);

        $response_data['order_number'] = $order_custom_id;

        $result['code']     =  strval(1);
        $result['message']  =  'order_sucessfully_placed';
        $result['result']   =  $response_data;

        $mainResult   =   $result;
        return response()->json(new \App\Http\Resources\V1\SettingResource($mainResult));
    }

    public function save_payment(Request $request)
    {


logger()->info("+++++++++++++++++++++++++++        CheckoutController - save_payment+++++++++++++++++++++++");
        logger()->info($request->all());
        
        logger()->info("-----------------------------------------");
        
        $result = [];
        $validator = \Validator::make($request->all(), [
            'order_id' => 'required',
            'transaction_id' => 'required',
            'user_id' => 'required',
            'uniqid' => 'required',
            'token' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'code' => strval(0),
                'error' => $validator->messages(),
                'data' => null
            ], 200);
        }
        
       

        $response = \App\Helpers\ResponseHelper::userCheckStatus($request->uniqid, $request->token);
        
        
           logger()->info("+++++++++++++++++++++++++++request - token+++++++++++++++++++++++");
        logger()->info($response);
        
        logger()->info("-----------------------------------------");
        if ($response['code'] != 1) {
            $mainResult   =   $response;
            return response()->json(new \App\Http\Resources\V1\SettingResource($mainResult));
        }

        $orderId = $request->order_id;
        $userId = $request->user_id;
        
        
        
        logger()->info("+++++++++++++++++++++++++++request - token+++++++++++++++++++++++");
        logger()->info($request->all());
        
        logger()->info("-----------------------------------------");

        $checkTransaction = \Helper::TransactionStatus($request->generate_token);
        
        logger()->info("+++++++++++++++++++++++++++CheckoutController - checkTransaction+++++++++++++++++++++++");
        logger()->info($checkTransaction);
        
        logger()->info("-----------------------------------------");
        if ($checkTransaction != false) {
            $orderData = Order::find($orderId);
            $orderData->status = 1;
            if ($orderData->save()) {
                try {
                    $tranId = @$request->transaction_id ?: $this->geneateTranscationId();
                    $transactions = Transactions::where('order_id', $orderId)->update(['status' => 1]);

                    $orderDetails = OrderDetails::where('order_id', $orderData->id)->get();

                    if (!empty($orderDetails) && $orderData->is_stock_updated != 1) {
                        foreach ($orderDetails as $item) {
                            $existing = ProductVariants::find($item->variant_id);
                            $available_qty = $existing->available_qty - $item->quantity;
                            $sold_qty = $existing->sold_qty + $item->quantity;

                            $existing->available_qty = $available_qty;
                            $existing->sold_qty = $sold_qty;
                            $existing->save();
                        }
                        $updatStockStatus = Order::find($orderData->id);
                        $updatStockStatus->is_stock_updated = 1;
                        $updatStockStatus->save();

                        $userData = DB::table('main_users')->where('id', $userId)->first();
                        $title = "Online Order Confirm";
                        $message = "Online Order Confirm";
                        $remember_token = "fYPZqDsO90pgmZAzTKD0ow:APA91bEF6Pv3waTLBb8lRSUCrjz_M3Vxf14zF3IDHBckRoI79Ojw66aRbuDNhuHWT21qsPYwhOvXxGhILv-nJ0ZCNWzEEuo2tWQ1pDULgeBkPPoAbPaV6ulPJ0W1H8zhA2IcPn8zHl8P";
                        $device_token = $userData->device_token;
                        // echo "<pre>";print_r($device_token);exit();
                        $device_type = 1;

                        $notification = new Notification();
                        $notification->order_id = @$orderData->id;
                        $notification->sender_id = @$userId;
                        $notification->receiver_id = @$userId;
                        $notification->notification_type = 1;
                        $notification->title = @$title;
                        $notification->message = @$message;
                        $notification->is_read = 0;
                        $notification->save();
                        
                            $admin_notification = new AdminNotifications();
                            $admin_notification->order_id = @$orderData->id;
                            $admin_notification->sender_id = @$userId;
                            $admin_notification->receiver_id = @$userId;
                            $admin_notification->notification_type = 1;
                            $admin_notification->title = @$title;
                            $admin_notification->message = @$message;
                            $admin_notification->is_read = 0;
                            $admin_notification->save();

                       // \Helper::sendNotification($device_token, $title, $message, @$orderData->id, @$orderData->order_id);

                        $this->sendOrderConfirmationEmail($userId, $orderData);

                        $response_data['order_number'] = @$orderData->order_id;
                        $result['code']     =  strval(1);
                        $result['message']  =  'success';
                        $result['result']   =  $response_data;

                        $mainResult   =   $result;
                        return response()->json(new \App\Http\Resources\V1\SettingResource($mainResult));
                    }
                } catch (\Throwable $th) {
                    $result['code']     =  strval(0);
                    $result['message']  =  'something_went_wrong';
                    $result['error_type']  =  'payment_failed';
                    $result['result']   =  NULL;

                    $mainResult   =   $result;
                    return response()->json(new \App\Http\Resources\V1\SettingResource($mainResult));
                }
            }
        } else {
            $result['code']     =  strval(0);
            $result['message']  =  'something_went_wrong';
            $result['error_type']  =  'payment_failed';
            $result['result']   =  NULL;

            $mainResult   =   $result;
            return response()->json(new \App\Http\Resources\V1\SettingResource($mainResult));
        }
    }
}
